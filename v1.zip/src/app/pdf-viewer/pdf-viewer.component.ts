import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer';
import { PdfCoordinateService, PdfCoordinate } from '../services/pdf-coordinate.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { lastValueFrom } from 'rxjs';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

// --- NEW IMPORTS (from detection.component.ts) ---
// (You will need to adjust these paths if they are incorrect)
// import { DashboardService } from '../../../services'; 
// import { BASE_URL } from '../../../utils/constant';

declare global {
  interface Window {
    pdfjsLib: any;
  }
  // Add this interface to match the one from detection.component.ts
  interface ButtonConfig {
    id: string;
    label: string;
    name?: string;
    icon?: string;
    svgPath?: string;
    action: () => void;
  }
}

@Component({
  selector: 'app-pdf-viewer',
  // Make sure you have HttpClientModule and FormsModule imported
  imports: [NgxExtendedPdfViewerModule, HttpClientModule, FormsModule, CommonModule],
  templateUrl: './pdf-viewer.component.html',
  styleUrl: './pdf-viewer.component.scss'
})
export class PdfViewerComponent implements OnInit, OnDestroy {
  // --- Existing Properties ---
  // I'm changing this to the full URL from your old component so the API call works
  // pdfSrc = 'http://orion:82/themes/uploads/test_drawings/WSS%20Combined%20Complete%20Set%20Plans.pdf';
  pdfSrc = '/assets/test.pdf';
  height = '100vh';
  private pdfDocument: any = null;
  private currentPage: any = null; // <-- NEW: To track current page object

  // --- NEW Properties (from detection.component.ts) ---
  
  // XML Annotation State
  xmlDoc: Document | null = null;
  xmlUrl: string = '/assets/test-annotations.xml'; // Using the XML file from our previous step

  // Project Info
  projectId: string = '';
  projectNumber: string = '';
  revisionId: number = 1;
  revisionNo: number = 1;
  
  // Checkbox State
  checkboxes = {
    site: false,
    building: false,
    door: false,
    frame: false,
    hw : false,
    ta: false,
    legend : false,
    pdfControls: false
  };

  // Panel Drag/Toggle State
  panelPositions = {
    site: { x: 8, y: 8 },
    building: { x: 12, y: 40 },
    door: { x: 16, y: 40 },
    frame: { x: 20, y: 40 },
    hw: { x: 24, y: 40 },
    ta: { x: 30, y: 40 },
    legend : { x: 34, y: 40 },
    pdfControls: { x: 8, y: 80 }
  };
  checkboxGroupPosition = { x: 80, y: 0 }; // Adjusted initial X
  isCheckboxGroupDragging = false;
  checkboxGroupDragOffset = { x: 0, y: 0 };
  checkboxGroupOrientation = false; // false = horizontal
  private checkboxGroupSmartInteraction = { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false };

  alignmentGuides = {
    show: false,
    horizontal: [] as number[],
    vertical: [] as number[],
    snapThreshold: 15
  };
  
  draggingStates = { site: false, building: false, door: false, frame: false, hw : false, ta: false, legend : false, pdfControls: false };
  orientationStates = { site: true, building: true, door: true, frame: true, hw : true, ta: true, legend : true, pdfControls: true };
  dragOffsets = { site: { x: 0, y: 0 }, building: { x: 0, y: 0 }, door: { x: 0, y: 0 }, frame: { x: 0, y: 0 }, hw: { x: 0, y: 0 }, ta: { x: 0, y: 0 }, legend : { x: 0, y: 0 }, pdfControls: { x: 0, y: 0 } };
  
  private smartInteractionStates = {
    site: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    building: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    door: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    frame: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    hw: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    ta: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    legend : { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    pdfControls: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false }
  };

  // Button State
  selectedButtonId: string | null = null;
  
  // Button Definitions (Copied from detection.component.ts)
  buttonGroups = {
    site: [
      { id: 'site_building', label: 'BL', name: 'Building', action: () => this.onButtonClick('site_building') }
    ] as ButtonConfig[],
    building: [
      { id: 'building_floor', label: 'FL', name: 'Floor', action: () => this.onButtonClick('building_floor') },
      { id: 'building_room_name', label: 'RN', name: 'Room Name', action: () => this.onButtonClick('building_room_name') },
      { id: 'building_room_number', label: 'R#', name: 'Room Number', action: () => this.onButtonClick('building_room_number') },
      // ... (add all other buttons from your old file) ...
    ] as ButtonConfig[],
    door: [
      { id: 'single_swing', label: 'SW1', name: 'Single Swing', action: () => this.onButtonClick('single_swing') },
      { id: 'double_swing', label: 'SW2', name: 'Double Swing', action: () => this.onButtonClick('double_swing') },
      // ... (add all other buttons) ...
    ] as ButtonConfig[],
    frame: [
      { id: 'wrap_around', label: 'WR', name: 'Wrap Around', action: () => this.onButtonClick('wrap_around') },
      { id: 'butt', label: 'BT', name: 'Butt', action: () => this.onButtonClick('butt') }
    ] as ButtonConfig[],
    hw: [
      { id: 'hw_set', label: 'HW', name: 'HW Set', action: () => this.onButtonClick('hw_set') }
    ] as ButtonConfig[],
    ta: [] as ButtonConfig[],
    legend: [] as ButtonConfig[],
  };
  

  constructor(
    private coordinateService: PdfCoordinateService,
    private http: HttpClient,
    // --- NEW INJECTION ---
    // private dashboardService: DashboardService 
  ) {}

  ngOnInit() {
    this.configureWorker();
    this.loadXmlAnnotations(); // <-- Use the robust XML loader
    
    // Listen for project changes from header
    window.addEventListener('dashboardHeaderEvent', this.handleHeaderEvent.bind(this));
  }

  ngOnDestroy() {
    // Clean up event listener
    window.removeEventListener('dashboardHeaderEvent', this.handleHeaderEvent.bind(this));
  }

  private configureWorker() {
    if (typeof window !== 'undefined') {
      window.pdfjsLib = window.pdfjsLib || {};
      window.pdfjsLib.GlobalWorkerOptions = {
        workerSrc: '/assets/pdf.worker.min.js'
      };
      console.log('✅ PDF.js Worker configured');
    }
  }

  // --- MODIFIED: `onPageRendered` ---
  // This is now the core of the rendering logic
  onPageRendered(event: any): void {
    const pageView = event.source;
    const pageElement = pageView.div as HTMLElement;
    const pageNumber = event.pageNumber;
    const pdfDocument = pageView.pdfDocument;
    const viewport = pageView.viewport;

    // Store the PDF.js page object
    this.currentPage = pageView.pdfPage;

    // Initialize service if new document
    if (pdfDocument && this.pdfDocument !== pdfDocument) {
      console.log('New PDF document loaded. Initializing coordinate service.');
      this.pdfDocument = pdfDocument;
      this.coordinateService.initializePdfDocument(this.pdfDocument);
    }
    
    // Store viewport
    if (viewport) {
      this.coordinateService.setPageViewport(pageNumber, viewport);
    } else {
      console.warn(`No viewport found in onPageRendered event for page ${pageNumber}`);
      return; 
    }

    // Set up coordinate tracking (click listener)
    if (pageElement && !(pageElement as any)._coordinateTrackingSetup) {
      console.log(`Setting up coordinate tracking for page ${pageNumber}`);
      (pageElement as any)._coordinateTrackingSetup = true;
      pageElement.style.cursor = 'crosshair';
      pageElement.style.border = '1px solid rgba(255, 0, 0, 0.5)';
      
      pageElement.addEventListener('click', (mouseEvent: MouseEvent) => {
        this.handlePageClick(mouseEvent, pageNumber);
      });

      pageElement.addEventListener('touchstart', (touchEvent: TouchEvent) => {
        touchEvent.preventDefault();
        this.handlePageTouch(touchEvent, pageNumber);
      });
    }
    
    // --- NEW: Render SVG Overlay ---
    // This replaces the simple div-based rendering
    
    // Make sure page div is ready for absolutely positioned children
    pageElement.style.position = 'relative';

    // Clear any old SVG overlay from this page div
    pageElement.querySelector('.annotation-svg-overlay')?.remove();

    // Create a new SVG overlay for this page
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'annotation-svg-overlay');
    // Set SVG size from viewport
    svg.setAttribute('width', viewport.width.toString());
    svg.setAttribute('height', viewport.height.toString());

    pageElement.appendChild(svg);

    // Call the robust XML rendering function
    if (this.xmlDoc) {
      this.renderXmlAnnotations(svg, viewport, pageNumber);
    }
  }

  // --- MODIFIED: `handlePageClick` ---
  // This now triggers the API call
  private handlePageClick(event: MouseEvent, pageNumber: number): void {
    // 1. Check if a button is selected
    if (!this.selectedButtonId) {
      // If not, just do the coordinate logging (original behavior)
      const coordinates = this.coordinateService.getPdfCoordinates(event, pageNumber);
      if (coordinates) {
        this.coordinateService.logCoordinates(coordinates);
        this.coordinateService.copyCoordinatesToClipboard(coordinates);
        this.showCoordinateNotification(coordinates);
      }
      return;
    }

    // 2. A button IS selected. Get PDF coordinates.
    const coordinates = this.coordinateService.getPdfCoordinates(event, pageNumber);
    if (!coordinates) return;

    // 3. Convert to the coordinate system your API expects (Y-flipped)
    const viewport = this.coordinateService['pageViewports'].get(pageNumber);
    if (!viewport) {
      console.error("Cannot get viewport for Y-flip");
      return;
    }

    // Get the *unscaled* page height
    const unscaledPageHeight = viewport.height / viewport.scale;
    
    // Our service gives X/Y from top-left. Your API needs Y from bottom-left.
    const pdfX = coordinates.x;
    const pdfY_bottom_left = unscaledPageHeight - coordinates.y; // The flip

    console.log(`Calling API. Button: ${this.selectedButtonId}, Page: ${pageNumber}, X: ${pdfX.toFixed(2)}, Y (flipped): ${pdfY_bottom_left.toFixed(2)}`);

    // 4. Call the API
    this.extractTextAtLocation(pdfX, pdfY_bottom_left, pageNumber, this.selectedButtonId);
    
    // 5. Deselect the button after use
    this.selectedButtonId = null;
  }

  // Handle touch (simplified, can be expanded)
  private handlePageTouch(event: TouchEvent, pageNumber: number): void {
    if (!this.selectedButtonId) {
      const coordinates = this.coordinateService.getPdfCoordinatesFromTouch(event, pageNumber);
      if (coordinates) {
        this.coordinateService.logCoordinates(coordinates);
        this.coordinateService.copyCoordinatesToClipboard(coordinates);
        this.showCoordinateNotification(coordinates);
      }
      return;
    }
    // ... (Add logic for touch-based annotation creation if needed) ...
  }

  // --- ALL NEW METHODS (Copied & Adapted from detection.component.ts) ---

  // Button click (selects button)
  onButtonClick(buttonId: string): void {
    if (this.selectedButtonId === buttonId) {
      this.selectedButtonId = null;
    } else {
      this.selectedButtonId = buttonId;
    }
    console.log('Selected button:', this.selectedButtonId);
  }

  // Robust XML Loader
  async loadXmlAnnotations(): Promise<void> {
    try {
      console.log('🎨 Loading XML Annotations Document from:', this.xmlUrl);
      const response = await fetch(this.xmlUrl);
      
      if (!response.ok) {
        console.warn('⚠️ XML file not found, creating new annotations document');
        const parser = new DOMParser();
        this.xmlDoc = parser.parseFromString('<?xml version="1.0" encoding="UTF-8"?><annotations></annotations>', 'application/xml');
        return;
      }
      
      const xmlString = await response.text();
      const parser = new DOMParser();
      this.xmlDoc = parser.parseFromString(xmlString, 'application/xml');
      
      const parserError = this.xmlDoc.querySelector('parsererror');
      if (parserError) {
        console.error('❌ XML parsing error:', parserError.textContent);
        this.xmlDoc = parser.parseFromString('<?xml version="1.0" encoding="UTF-8"?><annotations></annotations>', 'application/xml');
      } else {
        console.log('✅ XML parsed successfully');
      }
    } catch (error) {
      console.error('❌ Error loading XML annotations:', error);
      const parser = new DOMParser();
      this.xmlDoc = parser.parseFromString('<?xml version="1.0" encoding="UTF-8"?><annotations></annotations>', 'application/xml');
    }
  }

  // Render XML onto a specific SVG overlay
  // renderXmlAnnotations(svg: SVGElement, pageViewport: any, pageNumber: number): void {
  //   if (!this.xmlDoc) return;

  //   const pageHeight = pageViewport.height;
  //   const flipY = (y: number, height: number) => pageHeight - y;

  //   // Find all annotations for *this page*
  //   const annotations = Array.from(this.xmlDoc.documentElement.children)
  //     .filter(el => el.getAttribute('page') === pageNumber.toString());
      
  //   console.log(`Rendering ${annotations.length} XML annotations for page ${pageNumber}`);

  //   annotations.forEach(node => {
  //     // Logic from your old `renderXmlAnnotations`
  //     if (node.tagName === 'highlight') {
  //       const x1 = +node.getAttribute('x1')!;
  //       const y1 = +node.getAttribute('y1')!;
  //       const x2 = +node.getAttribute('x2')!;
  //       const y2 = +node.getAttribute('y2')!;
  //       const color = node.getAttribute('color') || 'rgba(255,255,0,0.4)';
        
  //       // Convert PDF coordinates (bottom-left) to viewport coordinates (top-left)
  //       const [viewportX1, viewportY1_flipped] = pageViewport.convertToViewportPoint(x1, y1);
  //       const [viewportX2, viewportY2_flipped] = pageViewport.convertToViewportPoint(x2, y2);
        
  //       // Y-axis is already flipped by PDF.js, but we need to find the top-left corner
  //       const rectX = Math.min(viewportX1, viewportX2);
  //       const rectY = Math.min(viewportY1_flipped, viewportY2_flipped); // Y is from top
  //       const rectWidth = Math.abs(viewportX2 - viewportX1);
  //       const rectHeight = Math.abs(viewportY2_flipped - viewportY1_flipped);

  //       const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
  //       rect.setAttribute('x', `${rectX}`);
  //       rect.setAttribute('y', `${rectY}`); // Use 'rectY' directly
  //       rect.setAttribute('width', `${rectWidth}`);
  //       rect.setAttribute('height', `${rectHeight}`);
  //       rect.setAttribute('fill', color);
  //       svg.appendChild(rect);
  //     }
  //     // ... (add logic for 'rect' and 'text' tags if you need them) ...
  //   });
  // }

  /**
   * Render XML onto a specific SVG overlay
   * --- THIS FUNCTION IS NOW FIXED ---
   */
  renderXmlAnnotations(svg: SVGElement, pageViewport: any, pageNumber: number): void {
    if (!this.xmlDoc) return;

    // 1. Find the <page> element for the current page number
    const pageNode = this.xmlDoc.querySelector(`page[number="${pageNumber}"]`);
    
    if (!pageNode) {
      // This is the expected log if a page truly has no annotations
      console.log(`Rendering 0 XML annotations for page ${pageNumber} (No <page> node found)`);
      return;
    }

    // 2. Get all <annotation> children from *that* page node
    const annotations = Array.from(pageNode.querySelectorAll('annotation'));
    
    // This log will now show the correct count
    console.log(`Rendering ${annotations.length} XML annotations for page ${pageNumber}`);
    
    if (annotations.length === 0) return;

    const pageHeight = pageViewport.height;

    annotations.forEach(node => {
      // 3. Get attributes from the <annotation> tag
      const x = +node.getAttribute('x')!;
      const y = +node.getAttribute('y')!;
      const width = +node.getAttribute('width')!;
      const height = +node.getAttribute('height')!;
      const type = node.getAttribute('type') || 'box';

      // 4. Get color based on type (using your getButtonHighlightColor logic)
      const color = this.getButtonHighlightColor(type);

      // 5. Convert PDF coordinates (top-left) to viewport coordinates
      const [viewportX, viewportY] = pageViewport.convertToViewportPoint(x, y);
      
      // 6. Scale dimensions
      const scaledWidth = width * pageViewport.scale;
      const scaledHeight = height * pageViewport.scale;

      const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', `${viewportX}`);
      rect.setAttribute('y', `${viewportY}`);
      rect.setAttribute('width', `${scaledWidth}`);
      rect.setAttribute('height', `${scaledHeight}`);
      rect.setAttribute('fill', color);
      rect.setAttribute('stroke', color.replace('0.4', '0.8')); // Darker border
      rect.setAttribute('stroke-width', '1');
      svg.appendChild(rect);
    });
  }



  /**
   * Helper function to get color for an annotation type
   */
  getButtonHighlightColor(buttonId: string): string {
    const colorMap: Record<string, string> = {
      // Site
      'site_building': 'rgba(135, 123, 152, 0.4)',
      // Building
      'building_floor': 'rgba(195, 190, 92, 0.4)',
      'building_room_name': 'rgba(195, 190, 92, 0.4)',
      'building_room_number': 'rgba(195, 190, 92, 0.4)',
      // Door
      'single_swing': 'rgba(90, 102, 98, 0.4)',
      'double_swing': 'rgba(90, 102, 98, 0.4)',
      // Frame
      'wrap_around': 'rgba(101, 151, 132, 0.4)',
      'butt': 'rgba(101, 151, 132, 0.4)',
      // HW
      'hw_set': 'rgba(119, 140, 151, 0.4)',
      // XML 'box' type
      'box': 'rgba(0, 123, 255, 0.15)',
    };
    
    // Add all other button IDs and their colors
    
    return colorMap[buttonId] || 'rgba(255, 255, 0, 0.4)'; // Default yellow
  }

  // Call API
  async extractTextAtLocation(x: number, y: number, pageNumber: number, buttonId: string): Promise<void> {
    try {
      // Use pdfSrc (which we set to the full URL)
      const relativePath = this.pdfSrc.split("orionprojects")[1];
      if (!relativePath) {
        console.error("Cannot extract API path from pdfSrc. 'orionprojects' not found.", this.pdfSrc);
        return;
      }
      
      const trimmedPath = `orionprojects${relativePath}`;
      const requestBody = { 
        pdf_file_path: trimmedPath,
        x, y, page: pageNumber, buttonId 
      };
      console.log('Making API call with:', requestBody);
  
      // const response: any = await lastValueFrom(
      //   this.dashboardService.getTextonDrop(requestBody)
      // );
       const response: any =  []; // --- MOCK RESPONSE FOR TESTING ---
  
  
      console.log('Service Response:', response);
  
      if (response?.data?.data?.bboxes?.length > 0) {
        const bboxes = typeof response.data.data.bboxes[0] === 'number' 
          ? [response.data.data.bboxes] 
          : response.data.data.bboxes;
        
        // Call the adapted highlight function
        this.highlightTextRegions(pageNumber, bboxes, response.data.data.text, buttonId);
      } else {
        console.warn('No bounding boxes returned from API.');
        // Here you could call your `createManualRectangle` logic if you port that over
      }
    } catch (error) {
      console.error('Error extracting text:', error);
    }
  }

  // Add highlight to XML and draw it on the *visible* SVG
  // highlightTextRegions(pageNumber: number, bboxes: number[][], detectedText: string, buttonId: string) {
  //   if (!this.xmlDoc) return;

  //   // --- 1. Find the Page's Viewport and SVG ---
    
  //   // Get the viewport from our service
  //   const viewport = this.coordinateService['pageViewports'].get(pageNumber);
  //   if (!viewport) {
  //     console.error(`No viewport for page ${pageNumber}. Cannot draw highlight.`);
  //     return;
  //   }
    
  //   // Find the visible page element and its SVG overlay
  //   // `ngx-extended-pdf-viewer` adds a class `.page` and `data-page-number`
  //   const pageElement = document.querySelector(`.page[data-page-number="${pageNumber}"]`);
  //   if (!pageElement) {
  //     console.warn(`Page ${pageNumber} not visible. Annotation will be saved to XML and drawn on next render.`);
  //     // We can still save to XML even if not visible
  //   }
    
  //   const svg = pageElement?.querySelector('.annotation-svg-overlay') as SVGElement | null;
  //   const pageHeight = viewport.height;
    
  //   for (const [x1, y1, x2, y2] of bboxes) {
  //     const colorMap: Record<string, string> = {
  //       site_building: "rgba(135, 123, 152, 0.4)",
  //       building_floor: "rgba(195, 190, 92, 0.4)",
  //       single_swing: "rgba(90, 102, 98, 0.4)",
  //       wrap_around: "rgba(101, 151, 132, 0.4)",
  //       hw_set: "rgba(119, 140, 151, 0.4)",
  //       // ... (add all other colors) ...
  //     };
  //     const color = colorMap[buttonId] || "rgba(255, 255, 0, 0.4)";

  //     // --- 2. Add to XML (uses original PDF coordinates) ---
  //     const highlightNode = this.xmlDoc.createElement("highlight");
  //     highlightNode.setAttribute("page", pageNumber.toString());
  //     highlightNode.setAttribute("x1", x1.toFixed(2));
  //     highlightNode.setAttribute("y1", y1.toFixed(2)); // API gives bottom-left Y
  //     highlightNode.setAttribute("x2", x2.toFixed(2));
  //     highlightNode.setAttribute("y2", y2.toFixed(2));
  //     highlightNode.setAttribute("color", color);
  //     highlightNode.setAttribute("label", buttonId);
  //     highlightNode.setAttribute("text", detectedText || '');
  //     this.xmlDoc.documentElement.appendChild(highlightNode);

  //     // --- 3. Draw on visible SVG (if it exists) ---
  //     if (svg) {
  //       // Convert PDF coordinates (bottom-left) to viewport coordinates (top-left)
  //       const [viewportX1, viewportY1_flipped] = viewport.convertToViewportPoint(x1, y1);
  //       const [viewportX2, viewportY2_flipped] = viewport.convertToViewportPoint(x2, y2);
        
  //       const rectX = Math.min(viewportX1, viewportX2);
  //       const rectY = Math.min(viewportY1_flipped, viewportY2_flipped); // Y is from top
  //       const rectWidth = Math.abs(viewportX2 - viewportX1);
  //       const rectHeight = Math.abs(viewportY2_flipped - viewportY1_flipped);

  //       const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
  //       rect.setAttribute("x", `${rectX}`);
  //       rect.setAttribute("y", `${rectY}`);
  //       rect.setAttribute("width", `${rectWidth}`);
  //       rect.setAttribute("height", `${rectHeight}`);
  //       rect.setAttribute("fill", color);
  //       svg.appendChild(rect);
        
  //       console.log(`Drew new highlight for ${buttonId} on visible page ${pageNumber}`);
  //     }
  //   }

  //   // --- 4. Save to Server ---
  //   this.saveXmlToServer(buttonId, detectedText);
  // }


  // In pdf-viewer.component.ts

  /**
   * Add highlight to XML and draw it on the *visible* SVG
   * --- THIS FUNCTION IS NOW FIXED ---
   */
  highlightTextRegions(pageNumber: number, bboxes: number[][], detectedText: string, buttonId: string) {
    if (!this.xmlDoc) {
      console.error("Cannot save annotation, xmlDoc is not loaded.");
      return;
    }

    // 1. Find the Page's Viewport and SVG
    const viewport = this.coordinateService['pageViewports'].get(pageNumber);
    if (!viewport) {
      console.error(`No viewport for page ${pageNumber}. Cannot draw highlight.`);
      return;
    }
    const pageElement = document.querySelector(`.page[data-page-number="${pageNumber}"]`);
    const svg = pageElement?.querySelector('.annotation-svg-overlay') as SVGElement | null;
    
    // --- 2. Find or Create the <page> node in the XML ---
    let pageNode = this.xmlDoc.querySelector(`page[number="${pageNumber}"]`);
    if (!pageNode) {
      pageNode = this.xmlDoc.createElement('page');
      pageNode.setAttribute('number', pageNumber.toString());
      this.xmlDoc.documentElement.appendChild(pageNode);
      console.log(`Created new <page number="${pageNumber}"> node in XML.`);
    }

    for (const [x1, y1, x2, y2] of bboxes) {
      const color = this.getButtonHighlightColor(buttonId);

      // 3. Convert bbox (x1, y1, x2, y2) to (x, y, width, height)
      // Assuming API returns top-left (x1, y1) and bottom-right (x2, y2)
      // And assuming Y-coordinates are from top-left (which our service provides)
      const x = Math.min(x1, x2);
      const y = Math.min(y1, y2); // This is the PDF's top-left Y
      const width = Math.abs(x2 - x1);
      const height = Math.abs(y2 - y1);
      
      // --- 4. Create an <annotation> node (NOT <highlight>) ---
      const annotationNode = this.xmlDoc.createElement("annotation");
      annotationNode.setAttribute("type", buttonId); // Store the button ID as 'type'
      annotationNode.setAttribute("x", x.toFixed(2));
      annotationNode.setAttribute("y", y.toFixed(2));
      annotationNode.setAttribute("width", width.toFixed(2));
      annotationNode.setAttribute("height", height.toFixed(2));
      
      // Add text child
      const textNode = this.xmlDoc.createElement('text');
      textNode.textContent = detectedText || '';
      annotationNode.appendChild(textNode);
      
      // --- 5. Append to the correct <page> node ---
      pageNode.appendChild(annotationNode);

      // --- 6. Draw on visible SVG (if it exists) ---
      if (svg) {
        const [viewportX, viewportY] = viewport.convertToViewportPoint(x, y);
        const scaledWidth = width * viewport.scale;
        const scaledHeight = height * viewport.scale;

        const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        rect.setAttribute("x", `${viewportX}`);
        rect.setAttribute("y", `${viewportY}`);
        rect.setAttribute("width", `${scaledWidth}`);
        rect.setAttribute("height", `${scaledHeight}`);
        rect.setAttribute("fill", color);
        rect.setAttribute('stroke', color.replace('0.4', '0.8'));
        rect.setAttribute('stroke-width', '1');
        svg.appendChild(rect);
        
        console.log(`Drew new highlight for ${buttonId} on visible page ${pageNumber}`);
      }
    }

    // --- 7. Save to Server ---
    this.saveXmlToServer(buttonId, detectedText);
  }

  // Save XML
  saveXmlToServer(buttonControlId?: string, text?: string) {
    if (!this.xmlDoc) return;
    const serializer = new XMLSerializer();
    const xmlString = serializer.serializeToString(this.xmlDoc);

    const pdfPath = this.pdfSrc ? this.pdfSrc.split("orionprojects")[1] : 'unknown.pdf';
    
    const payload: any = {
      pdfPath: `orionprojects${pdfPath}`,
      xmlContent: xmlString,
      buttonControlId: buttonControlId,
      text: text,
      projectId: parseInt(this.projectId, 10),
      revisionId: this.revisionId,
      revisionNo: this.revisionNo,
    };

    // this.dashboardService.saveXmlAnnotations(payload).subscribe({
    //   next: (response) => console.log('✅ XML saved to server:', response),
    //   error: (err: any) => console.error('❌ Error saving XML to server:', err),
    // });
  }
  
  // --- All Panel/Checkbox Drag/Toggle Methods ---

  trackByButtonId(index: number, button: ButtonConfig): string {
    return button.id;
  }

  getButtonName(buttonId: string): string {
    for (const category of Object.keys(this.buttonGroups)) {
      const buttons = this.buttonGroups[category as keyof typeof this.buttonGroups];
      const button = buttons.find(btn => btn.id === buttonId);
      if (button) {
        return button.name || button.label;
      }
    }
    return buttonId;
  }

  isButtonSelected(buttonId: string): boolean {
    return this.selectedButtonId === buttonId;
  }

  onCheckboxChange(type: string, event: any): void {
    console.log(`${type} checkbox changed:`, event.target.checked);
  }

  getPanelStyle(category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls'): any {
    return {
      left: this.panelPositions[category].x + 'px',
      top: this.panelPositions[category].y + 'px',
      cursor: this.draggingStates[category] ? 'grabbing' : 'grab'
    };
  }

  getCheckboxGroupStyle(): any {
    return {
      left: this.checkboxGroupPosition.x + 'px',
      top: this.checkboxGroupPosition.y + 'px',
      cursor: this.isCheckboxGroupDragging ? 'grabbing' : 'grab'
    };
  }

  toggleOrientation(category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls'): void {
    this.orientationStates[category] = !this.orientationStates[category];
  }

  toggleCheckboxGroupOrientation(): void {
    this.checkboxGroupOrientation = !this.checkboxGroupOrientation;
  }

  // Smart click/drag for Panels
  onSmartMouseDown(event: MouseEvent, category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls'): void {
    this.smartInteractionStates[category].startTime = Date.now();
    this.smartInteractionStates[category].startPosition = { x: event.clientX, y: event.clientY };
    this.smartInteractionStates[category].hasMoved = false;
    this.draggingStates[category] = true;
    this.dragOffsets[category].x = event.clientX - this.panelPositions[category].x;
    this.dragOffsets[category].y = event.clientY - this.panelPositions[category].y;
    
    const moveHandler = (e: MouseEvent) => this.onSmartMouseMove(e, category);
    const upHandler = () => this.onSmartMouseUp(category, moveHandler, upHandler);
    
    document.addEventListener('mousemove', moveHandler);
    document.addEventListener('mouseup', upHandler);
    event.preventDefault();
  }

  onSmartMouseMove(event: MouseEvent, category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls'): void {
    if (!this.draggingStates[category]) return;
    
    const deltaX = Math.abs(event.clientX - this.smartInteractionStates[category].startPosition.x);
    const deltaY = Math.abs(event.clientY - this.smartInteractionStates[category].startPosition.y);

    if (deltaX > 5 || deltaY > 5) {
      this.smartInteractionStates[category].hasMoved = true;
      let newX = event.clientX - this.dragOffsets[category].x;
      let newY = event.clientY - this.dragOffsets[category].y;
      
      // ... (Alignment logic can be re-added here if needed) ...
      
      this.panelPositions[category].x = newX;
      this.panelPositions[category].y = newY;
    }
  }

  onSmartMouseUp(category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls', moveHandler: any, upHandler: any): void {
    this.draggingStates[category] = false;
    document.removeEventListener('mousemove', moveHandler);
    document.removeEventListener('mouseup', upHandler);
    
    if (!this.smartInteractionStates[category].hasMoved) {
      const timeDiff = Date.now() - this.smartInteractionStates[category].startTime;
      if (timeDiff < 200) {
        this.toggleOrientation(category);
      }
    }
    this.smartInteractionStates[category].hasMoved = false;
  }

  onSmartClick(event: MouseEvent, category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls'): void {
    if (this.smartInteractionStates[category].hasMoved) {
      event.preventDefault();
      event.stopPropagation();
    }
  }

  // Smart click/drag for Checkbox Group
  onCheckboxGroupSmartMouseDown(event: MouseEvent): void {
    this.checkboxGroupSmartInteraction.startTime = Date.now();
    this.checkboxGroupSmartInteraction.startPosition = { x: event.clientX, y: event.clientY };
    this.checkboxGroupSmartInteraction.hasMoved = false;
    this.isCheckboxGroupDragging = true;
    this.checkboxGroupDragOffset.x = event.clientX - this.checkboxGroupPosition.x;
    this.checkboxGroupDragOffset.y = event.clientY - this.checkboxGroupPosition.y;
    
    const moveHandler = (e: MouseEvent) => this.onCheckboxGroupSmartMouseMove(e);
    const upHandler = () => this.onCheckboxGroupSmartMouseUp(upHandler, moveHandler);
    
    document.addEventListener('mousemove', moveHandler);
    document.addEventListener('mouseup', upHandler);
    event.preventDefault();
  }

  onCheckboxGroupSmartMouseMove(event: MouseEvent): void {
    if (!this.isCheckboxGroupDragging) return;

    const deltaX = Math.abs(event.clientX - this.checkboxGroupSmartInteraction.startPosition.x);
    const deltaY = Math.abs(event.clientY - this.checkboxGroupSmartInteraction.startPosition.y);
      
    if (deltaX > 5 || deltaY > 5) {
      this.checkboxGroupSmartInteraction.hasMoved = true;
      this.checkboxGroupPosition.x = event.clientX - this.checkboxGroupDragOffset.x;
      this.checkboxGroupPosition.y = event.clientY - this.checkboxGroupDragOffset.y;
    }
  }

  onCheckboxGroupSmartMouseUp(upHandler: any, moveHandler: any): void {
    this.isCheckboxGroupDragging = false;
    document.removeEventListener('mousemove', moveHandler);
    document.removeEventListener('mouseup', upHandler);
    
    if (!this.checkboxGroupSmartInteraction.hasMoved) {
      const timeDiff = Date.now() - this.checkboxGroupSmartInteraction.startTime;
      if (timeDiff < 200) {
        this.toggleCheckboxGroupOrientation();
      }
    }
    this.checkboxGroupSmartInteraction.hasMoved = false;
  }

  onCheckboxGroupSmartClick(event: MouseEvent): void {
    if (this.checkboxGroupSmartInteraction.hasMoved) {
      event.preventDefault();
      event.stopPropagation();
    }
  }

  // PDF Control Panel Methods (Zoom, Rotate)
  onPdfZoomIn(): void {
    // This will call the built-in ngx-extended-pdf-viewer zoom
    (window as any).PDFViewerApplication.zoomIn();
  }
  
  onPdfZoomOut(): void {
    (window as any).PDFViewerApplication.zoomOut();
  }
  
  onPdfRotateLeft(): void {
    (window as any).PDFViewerApplication.rotatePagesCounterclockwise();
  }
  
  onPdfRotateRight(): void {
    (window as any).PDFViewerApplication.rotatePagesClockwise();
  }

  // Project Info Handler
  private handleHeaderEvent = (event: Event): void => {
    const customEvent = event as CustomEvent;
    const { eventType, data } = customEvent.detail;

    if (eventType === 'projectChanged') {
      console.log('Detection component received project change:', data);
      this.projectId = data.projectId || '';
      this.projectNumber = data.projectNumber || '';
      this.revisionId = data.revisionId || 1;
      this.revisionNo = data.revisionNo || 1;
    }
  }

  // Notification
  private showCoordinateNotification(coordinates: PdfCoordinate): void {
    const message = `Coordinates: Page ${coordinates.page}, X: ${coordinates.x}, Y: ${coordinates.y}`;
    const notification = document.createElement('div');
    notification.style.cssText = `... (style as before) ...`;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 3000);
  }
}