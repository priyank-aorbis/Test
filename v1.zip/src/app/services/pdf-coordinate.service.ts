import { Injectable } from '@angular/core';

export interface PdfCoordinate {
  page: number;
  x: number;
  y: number;
  scale: number;
  timestamp: Date;
}

@Injectable({
  providedIn: 'root'
})
export class PdfCoordinateService {
  private pdfDocument: any = null;
  private pageViewports: Map<number, any> = new Map();

  constructor() { }

  /**
   * Initialize PDF.js document and viewports
   */
  initializePdfDocument(pdfDoc: any): void {
    this.pdfDocument = pdfDoc;
    this.pageViewports.clear();
  }

  /**
   * Store page viewport for coordinate calculations
   */
  setPageViewport(pageNumber: number, viewport: any): void {
    this.pageViewports.set(pageNumber, viewport);
  }

  /**
   * Get PDF coordinates from mouse event
   * THIS IS THE CORRECTED IMPLEMENTATION
   */
  getPdfCoordinates(event: MouseEvent, pageNumber: number): PdfCoordinate | null {
    console.log('=== Coordinate Service Debug ===');
    console.log('Page Number:', pageNumber);

    // Get the page element (the one the listener was attached to)
    const pageElement = event.currentTarget as HTMLElement;
    if (!pageElement) {
      console.error('No event.currentTarget found.');
      return null;
    }

    const viewport = this.pageViewports.get(pageNumber);
    if (!viewport) {
      console.error('No viewport found for page', pageNumber);
      return null;
    }

    const scale = viewport.scale;
    const rect = pageElement.getBoundingClientRect();
    
    // Calculate offset coordinates relative to the page element
    // This is the correct, robust method, ignoring event.target
    const offsetX = event.clientX - rect.left;
    const offsetY = event.clientY - rect.top;
    
    const x = this.truncate(offsetX / scale);
    const y = this.truncate(offsetY / scale);
    
    console.log('Scale:', scale);
    console.log('Element Rect:', { left: rect.left, top: rect.top });
    console.log('Client Coords:', { clientX: event.clientX, clientY: event.clientY });
    console.log('Calculated offsets:', { offsetX: offsetX, offsetY: offsetY });
    console.log('Final coordinates:', { x, y });

    const result = {
      page: pageNumber,
      x: x,
      y: y,
      scale: scale, // Return the scale at which it was clicked
      timestamp: new Date()
    };
    
    console.log('Final result:', result);
    return result;
  }

  /**
   * Get PDF coordinates from touch event (for mobile)
   * Updated to use event.currentTarget
   */
  getPdfCoordinatesFromTouch(event: TouchEvent, pageNumber: number): PdfCoordinate | null {
    if (event.touches.length === 0) return null;

    const touch = event.touches[0];
    // Use event.currentTarget, not event.target
    const pageElement = event.currentTarget as HTMLElement;
    if (!pageElement) return null;

    const viewport = this.pageViewports.get(pageNumber);
    if (!viewport) return null;

    const scale = viewport.scale;
    const rect = pageElement.getBoundingClientRect();
    
    // Calculate offset coordinates
    const offsetX = touch.clientX - rect.left;
    const offsetY = touch.clientY - rect.top;
    
    const x = this.truncate(offsetX / scale);
    const y = this.truncate(offsetY / scale);

    return {
      page: pageNumber,
      x: x,
      y: y,
      scale: scale,
      timestamp: new Date()
    };
  }

  /**
   * Convert PDF coordinates to canvas coordinates
   */
  pdfToCanvasCoordinates(pdfCoord: PdfCoordinate): { x: number, y: number } {
    const viewport = this.pageViewports.get(pdfCoord.page);
    if (!viewport) return { x: 0, y: 0 };

    return {
      x: pdfCoord.x * viewport.scale,
      y: pdfCoord.y * viewport.scale
    };
  }

  // NOTE: getPageNumberFromCanvas is no longer needed and can be removed.

  /**
   * Truncate number to specified decimal places
   * Same implementation as xandy.html
   */
  private truncate(num: number, maxDecimalPlaces: number = 2): number {
    const regex = new RegExp(`^-?\\d+(?:\\.\\d{0,${maxDecimalPlaces}})?`);
    const match = num.toString().match(regex);
    return match ? parseFloat(match[0]) : num;
  }

  /**
   * Log coordinates to console (for debugging)
   */
  logCoordinates(coordinates: PdfCoordinate): void {
    console.log('PDF Coordinates:', {
      page: coordinates.page,
      x: coordinates.x,
      y: coordinates.y,
      scale: coordinates.scale,
      timestamp: coordinates.timestamp.toISOString()
    });
  }

  /**
   * Format coordinates as string (for clipboard copy)
   */
  formatCoordinates(coordinates: PdfCoordinate): string {
    return `Page: ${coordinates.page}, X: ${coordinates.x}, Y: ${coordinates.y}`;
  }

  /**
   * Copy coordinates to clipboard
   */
  async copyCoordinatesToClipboard(coordinates: PdfCoordinate): Promise<void> {
    try {
      const text = this.formatCoordinates(coordinates);
      await navigator.clipboard.writeText(text);
      console.log('Coordinates copied to clipboard:', text);
    } catch (error) {
      console.error('Failed to copy coordinates to clipboard:', error);
    }
  }
}