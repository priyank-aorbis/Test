import { Routes } from '@angular/router';
import { DetectionComponent } from '../detection/detection.component';
import {PdfCordComponent} from '../pdf-cord/pdf-cord.component';
import { PdfViewerComponent } from './pdf-viewer/pdf-viewer.component';

export const routes: Routes = [
  { path: 'detection', component: PdfCordComponent },
  { path: 'pdf-viewer', component: PdfViewerComponent },
  { path: '', redirectTo: '/pdf-viewer', pathMatch: 'full' },
  { path: '**', redirectTo: '/pdf-viewer' } // Catch-all route
];
