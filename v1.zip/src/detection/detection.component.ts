import { Component, Inject, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BehaviorSubject, lastValueFrom } from 'rxjs';
// import { GRID_WIDGET_DATA } from '../../share-data';
// import { PdfNavigationService } from '../../../services/pdf-navigation.service';
// import { DashboardService } from '../../../services';
// import { trigger, state, style, transition, animate } from '@angular/animations';
// import { BASE_URL } from '../../../utils/constant';

// Declare PDF.js types
declare const pdfjsLib: any;

interface ButtonConfig {
  id: string;
  label: string;
  name?: string; // Optional name property
  icon?: string;
  svgPath?: string;
  action: () => void;
}

@Component({
  selector: 'app-detection',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './detection.component.html',
  styleUrl: './detection.component.scss',
  animations: [
    // trigger('expandCollapse', [
    //   state('collapsed', style({ height: '0px', opacity: 0, overflow: 'hidden' })),
    //   state('expanded', style({ height: '*', opacity: 1, overflow: 'hidden' })),
    //   transition('collapsed <=> expanded', animate('300ms ease-in-out'))
    // ])
  ]
})

export class DetectionComponent implements OnInit, AfterViewInit {
  data: any = {};
  pageNumber: number = 1; // Default to page 1
  totalPages: number = 0; // Total pages in PDF
  currentScale: number = 0.35; // PDF scale
  currentRotation: number = 0; // Current rotation in degrees (0, 90, 180, 270)
  pdfDoc: any = null; // PDF.js document
  currentPage: any = null; // Current PDF page
  showMoreRows = false;
  currentPdf: any;
  showZoomDropdown = false;
  // Project information from header
  projectId: string = '';
  projectNumber: string = '';
  revisionId: number = 1;
  revisionNo: number = 1;

xmlDoc: Document | null = null;

// Optional: base path for XML files (you can adjust later)
  xmlUrl: string = './building_drawing.xml';

  @ViewChild('pdfCanvas', { static: false }) pdfCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('cropCanvas', { static: false }) cropCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('overlaySvg', { static: false }) overlaySvg!: ElementRef<SVGElement>;

  
  private pageCropRects = new Map<
    number,
    { x: number; y: number; width: number; height: number }[]
  >();
  private globalEventListeners: {
    element: Window | Document;
    event: string;
    handler: EventListener;
  }[] = [];
  private canvasEventListeners = new Map<HTMLCanvasElement, {
    pointerdown: (e: PointerEvent) => void;
    contextmenu: (e: Event) => void;
    click: (e: MouseEvent) => void;
  }>();

  // Selected button state (replaces drag and drop)
  selectedButtonId: string | null = null;
  private highlightedRegions = new Map<number, Array<{
    bbox: number[];
    color: string;
    text: string;
    buttonId: string;
  }>>();

  // Manual rectangle properties
  manualRectangles = new Map<string, {
    id: string;
    x: number;
    y: number;
    width: number;
    height: number;
    buttonId: string;
    pageNumber: number;
    isAdjusting: boolean;
    showControls: boolean;
  }>();
  private nextRectangleId = 1;
  
  checkboxes = {
    site: false,
    building: false,
    door: false,
    frame: false,
    hw : false,
    ta: false,
    legend : false,
    pdfControls: false
  };
  // PDF viewer state
  showPdfViewer = true; // Enable by default to see the layout
  // Using public directory path to load test.pdf - try multiple approaches
  pdfUrl = '/test.pdf'; // Try relative path first
  isLoading = false;

  // Draggable panel states for each category
  panelPositions = {
    site: { x: 8, y: 8 },
    building: { x: 12, y: 40 },
    door: { x: 16, y: 40 },
    frame: { x: 20, y: 40 },
    hw: { x: 24, y: 40 },
    ta: { x: 30, y: 40 },
    legend : { x: 34, y: 40 },
    pdfControls: { x: 8, y: 80 }
  };
  // Checkbox group drag state
  checkboxGroupPosition = { x: 0, y: 0 };
  isCheckboxGroupDragging = false;
  checkboxGroupDragOffset = { x: 0, y: 0 };
  checkboxGroupOrientation = false; // false = horizontal (default), true = vertical
  
  // Smart interaction tracking for checkbox group
  private checkboxGroupSmartInteraction = { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false };
  
  // Alignment guides for panel positioning
  alignmentGuides = {
    show: false,
    horizontal: [] as number[],
    vertical: [] as number[],
    snapThreshold: 15 // pixels
  };
  
  draggingStates = {
    site: false,
    building: false,
    door: false,
    frame: false,
    hw : false,
    ta: false,
    legend : false,
    pdfControls: false
  };
  
  orientationStates = {
    site: true, // true = vertical (default)
    building: true,
    door: true,
    frame: true,
    hw : true,
    ta: true,
    legend : true,
    pdfControls: true
  };
  
  dragOffsets = {
    site: { x: 0, y: 0 },
    building: { x: 0, y: 0 },
    door: { x: 0, y: 0 },
    frame: { x: 0, y: 0 },
    hw: { x: 0, y: 0 },
    ta: { x: 0, y: 0 },
    legend : { x: 0, y: 0 },
    pdfControls: { x: 0, y: 0 }
  };
  // Smart interaction tracking
  private smartInteractionStates = {
    site: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    building: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    door: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    frame: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    hw: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    ta: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    legend : { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false },
    pdfControls: { startTime: 0, startPosition: { x: 0, y: 0 }, hasMoved: false }
  };

  // Button groups for each category
  // buttonGroups = {
  //   // New building-related button groups
  //   site: [
  //     { id: 'site_plan', label: 'BL',  action: () => this.onSitePlanClick() }
  //   ] as ButtonConfig[],
  //   building: [
  //     { id: 'building_info', label: 'Floor', action: () => this.onBuildingClick() },
  //     // { id: 'building_info', label: 'Building', action: () => this.onBuildingClick() },

  //     // { id: 'building_layout', label: 'Layout', action: () => this.onBuildingLayoutClick() }
  //   ] as ButtonConfig[],
  //   door: [
  //     { id: 'single_swing', label: 'S-Swing', action: () => this.onButtonClick() },
  //     { id: 'double_swing', label: 'D-Swing', action: () => this.onButtonClick() },
  //     { id: 'double_bypass', label: 'D-Bypass', action: () => this.onDoubleBypassClick() },
  //     { id: 'triple_bypass', label: 'T-Bypass', action: () => this.onTripleBypassClick() },
  //     { id: 'quad_bypass', label: 'Q-Bypass', action: () => this.onQuadBypassClick() },
  //     { id: 'single_barn', label: 'S-Barn', action: () => this.onSingleBarnClick() },
  //     { id: 'double_barn', label: 'D-Barn', action: () => this.onDoubleBarnClick() },
  //     { id: 'single_bifold', label: 'S-Bifold', action: () => this.onSingleBifoldClick() },
  //     { id: 'double_bifold', label: 'D-Bifold', action: () => this.onDoubleBifoldClick() },
  //     { id: 'single_pocket', label: 'S-Pocket', action: () => this.onSinglePocketClick() },
  //     { id: 'double_pocket', label: 'D-Pocket', action: () => this.onDoublePocketClick() }
  //   ] as ButtonConfig[],
  //   frame: [
  //     { id: 'wrap_around', label: 'Wrap', action: () => this.onWrapAroundClick() },
  //     { id: 'butt', label: 'Butt', action: () => this.onButtClick() }
  //   ] as ButtonConfig[],
  //   hw: [
  //     { id: 'hw', label: 'HW', action: () => this.onHwClick() },
  //     { id: 'hw_set', label: 'HW Set', action: () => this.onHwSetClick() }
  //   ] as ButtonConfig[],
  //   ta: [
  //   ] as ButtonConfig[],
  // };

buttonGroups = {
  site: [
    { id: 'site_building', label: 'BL', name: 'Building', action: () => this.onButtonClick('site_building') }
  ] as ButtonConfig[],
  building: [
    { id: 'building_floor', label: 'FL', name: 'Floor', action: () => this.onButtonClick('building_floor') },
    { id: 'building_room_name', label: 'RN', name: 'Room Name', action: () => this.onButtonClick('building_room_name') },
    { id: 'building_room_number', label: 'R#', name: 'Room Number', action: () => this.onButtonClick('building_room_number') },
    { id: 'building_unit_name', label: 'UN', name: 'Unit Name', action: () => this.onButtonClick('building_unit_name') },
    { id: 'building_unit_number', label: 'U#', name: 'Unit Number', action: () => this.onButtonClick('building_unit_number') },
    { id: 'building_unit_bath_name', label: 'BN', name: 'Unit Bath Name', action: () => this.onButtonClick('building_unit_bath_name') },
    { id: 'building_unit_bath_number', label: 'B#', name: 'Unit Bath Number', action: () => this.onButtonClick('building_unit_bath_number') },
    { id: 'building_opening_number', label: 'O#', name: 'Opening Number', action: () => this.onButtonClick('building_opening_number') },
    { id: 'building_wall_type', label: 'WT', name: 'Wall Type', action: () => this.onButtonClick('building_wall_type') },
    { id: 'building_ada', label: 'ADA', name: 'ADA', action: () => this.onButtonClick('building_ada') },
    { id: 'building_connecting', label: 'CN', name: 'Connecting', action: () => this.onButtonClick('building_connecting') },
    { id: 'building_balcony', label: 'BC', name: 'Balcony', action: () => this.onButtonClick('building_balcony') },
    { id: 'building_ta_tag', label: 'TA', name: 'TA Tag', action: () => this.onButtonClick('building_ta_tag') }
  ] as ButtonConfig[],
  door: [
    { id: 'single_swing', label: 'SW1', name: 'Single Swing', action: () => this.onButtonClick('single_swing') },
    { id: 'double_swing', label: 'SW2', name: 'Double Swing', action: () => this.onButtonClick('double_swing') },
    { id: 'double_bypass', label: 'BP2', name: 'Double Bypass', action: () => this.onButtonClick('double_bypass') },
    { id: 'triple_bypass', label: 'BP3', name: 'Triple Bypass', action: () => this.onButtonClick('triple_bypass') },
    { id: 'quad_bypass', label: 'BP4', name: 'Quad Bypass', action: () => this.onButtonClick('quad_bypass') },
    { id: 'single_barn', label: 'BR1', name: 'Single Barn', action: () => this.onButtonClick('single_barn') },
    { id: 'double_barn', label: 'BR2', name: 'Double Barn', action: () => this.onButtonClick('double_barn') },
    { id: 'single_bifold', label: 'BF1', name: 'Single Bifold', action: () => this.onButtonClick('single_bifold') },
    { id: 'double_bifold', label: 'BF2', name: 'Double Bifold', action: () => this.onButtonClick('double_bifold') },
    { id: 'single_pocket', label: 'P01', name: 'Single Pocket', action: () => this.onButtonClick('single_pocket') },
    { id: 'double_pocket', label: 'P02', name: 'Double Pocket', action: () => this.onButtonClick('double_pocket') }
  ] as ButtonConfig[],
  frame: [
    { id: 'wrap_around', label: 'WR', name: 'Wrap Around', action: () => this.onButtonClick('wrap_around') },
    { id: 'butt', label: 'BT', name: 'Butt', action: () => this.onButtonClick('butt') }
  ] as ButtonConfig[],

  hw: [
    { id: 'hw_set', label: 'HW', name: 'HW Set', action: () => this.onButtonClick('hw_set') }
  ] as ButtonConfig[],

  ta: [
    // Future TA controls can go here
  ] as ButtonConfig[],

  legend: [
    // Future TA controls can go here
  ] as ButtonConfig[],
};


  // Get visible buttons based on checkbox selections
  get visibleButtons(): ButtonConfig[] {
    let buttons: ButtonConfig[] = [];
    
    if (this.checkboxes.site) {
      buttons = [...buttons, ...this.buttonGroups.site];
    }
    if (this.checkboxes.building) {
      buttons = [...buttons, ...this.buttonGroups.building];
    }
    if (this.checkboxes.door) {
      buttons = [...buttons, ...this.buttonGroups.door];
    }
     if (this.checkboxes.frame) {
      buttons = [...buttons, ...this.buttonGroups.frame];
    }
    if (this.checkboxes.hw) {
      buttons = [...buttons, ...this.buttonGroups.hw];
    }
    if (this.checkboxes.ta) {
      buttons = [...buttons, ...this.buttonGroups.ta];
    }
      if (this.checkboxes.legend) {
      buttons = [...buttons, ...this.buttonGroups.legend];
    }
    return buttons;
  }
toggleRows(): void {
    this.showMoreRows = !this.showMoreRows;
  }
  constructor(
    // @Inject(GRID_WIDGET_DATA) private widgetData: BehaviorSubject<any>,
    // private pdfNav: PdfNavigationService,
    // private dashboardService: DashboardService
  ) { }



  ngAfterViewInit(): void {
    // Set up PDF.js worker
    if (typeof pdfjsLib !== 'undefined') {
      pdfjsLib.GlobalWorkerOptions.workerSrc = 
        'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.9.179/pdf.worker.min.js';
      
      // Load PDF after view init
      setTimeout(() => {
        this.loadPdf();
      }, 100);
    } else {
      console.error('PDF.js library not loaded');
    }

    // Add click outside handler for zoom dropdown
    document.addEventListener('click', (event) => {
      if (this.showZoomDropdown) {
        const dropdown = document.querySelector('.zoom-dropdown-container');
        if (dropdown && !dropdown.contains(event.target as Node)) {
          this.showZoomDropdown = false;
        }
      }
    });
  }

  async loadPdf(): Promise<void> {
    if (!this.pdfUrl) {
      console.error('No PDF URL provided');
      return;
    }

    console.log('=== PDF Loading Debug ===');
    console.log('PDF URL:', this.pdfUrl);
    console.log('PDF.js available:', typeof pdfjsLib !== 'undefined');
    console.log('Worker source:', pdfjsLib?.GlobalWorkerOptions?.workerSrc);

    try {
      console.log('Attempting to load PDF from:', this.pdfUrl);
      this.pdfDoc = await pdfjsLib.getDocument(this.pdfUrl).promise;
      this.totalPages = this.pdfDoc.numPages;
      console.log(`✅ PDF loaded successfully with ${this.totalPages} pages`);
      
      // Load XML annotations once when PDF is loaded
      await this.loadXmlAnnotations();
      
      // Render the first page
      await this.renderPage(this.pageNumber);
    } catch (error) {
      console.error('❌ Error loading PDF:', error);
      // console.error('Error details:', {
      //   message: error?.message,
      //   name: error.name,
      //   stack: error.stack
      // });
      
      // Try fallback URLs
      const fallbackUrls = [
        'http://localhost:4201/test.pdf',
        './test.pdf',
        '/assets/test.pdf'
      ];
      
      console.log('Trying fallback URLs...');
      for (const fallbackUrl of fallbackUrls) {
        try {
          console.log(`Trying fallback URL: ${fallbackUrl}`);
          this.pdfUrl = fallbackUrl;
          this.pdfDoc = await pdfjsLib.getDocument(fallbackUrl).promise;
          this.totalPages = this.pdfDoc.numPages;
          console.log(`✅ PDF loaded successfully with fallback URL: ${fallbackUrl}`);
          await this.loadXmlAnnotations();
          await this.renderPage(this.pageNumber);
          return; // Success, exit the function
        } catch (fallbackError) {
          // console.warn(`Fallback URL ${fallbackUrl} also failed:`, fallbackError.message);
        }
      }
      
      // If all fallbacks fail
      this.onPdfLoadError(error);
    }
  }

  /* ═══════════════════════════════════════════════════════════════════════
   * 📝 XML ANNOTATIONS WORKFLOW
   * ═══════════════════════════════════════════════════════════════════════
   * 
   * 1. LOADING:
   *    - XML is loaded ONCE when PDF is loaded (loadXmlAnnotations)
   *    - Stored in this.xmlDoc for the session
   *    - Creates empty document if file doesn't exist
   * 
   * 2. RENDERING:
   *    - Annotations are rendered on each page change (renderXmlAnnotations)
   *    - Draws highlights, rectangles, and text from XML onto SVG overlay
   * 
   * 3. ADDING ANNOTATIONS:
   *    - User drags button and drops on PDF (onCanvasDrop)
   *    - extractTextAtLocation gets text/bbox from backend
   *    - highlightTextRegions adds to xmlDoc and draws on SVG
   * 
   * 4. SAVING:
   *    - saveXmlToServer is called after each annotation is added
   *    - Downloads XML file locally (can be modified to POST to backend)
   * 
   * ═══════════════════════════════════════════════════════════════════════ */

  // Load XML annotations document (called once when PDF loads)
  async loadXmlAnnotations(): Promise<void> {
    try {
      console.log('═══════════════════════════════════════');
      console.log('🎨 Loading XML Annotations Document');
      console.log('───────────────────────────────────────');
      // console.log('XML URL:', this.xmlUrl);
      
      const response = await fetch(this.xmlUrl);
      
      if (!response.ok) {
        console.warn('⚠️ XML file not found, creating new annotations document');
        const parser = new DOMParser();
        this.xmlDoc = parser.parseFromString('<?xml version="1.0" encoding="UTF-8"?><annotations></annotations>', 'application/xml');
        console.log('✅ Created new empty annotations document');
        return;
      }
      
      const xmlString = await response.text();
      console.log('✅ XML file fetched successfully');
      console.log('XML Content Length:', xmlString.length, 'characters');
      
      const parser = new DOMParser();
      this.xmlDoc = parser.parseFromString(xmlString, 'application/xml');
      
      // Check for parsing errors
      const parserError = this.xmlDoc.querySelector('parsererror');
      if (parserError) {
        console.error('❌ XML parsing error:', parserError.textContent);
        // Create fresh XML document on error
        this.xmlDoc = parser.parseFromString('<?xml version="1.0" encoding="UTF-8"?><annotations></annotations>', 'application/xml');
        console.log('✅ Created new empty annotations document due to parse error');
        return;
      }
      
      const annotationsCount = this.xmlDoc.documentElement.children.length;
      console.log('✅ XML parsed successfully');
      console.log(`📝 Found ${annotationsCount} existing annotations`);
      console.log('═══════════════════════════════════════');
      
    } catch (error) {
      console.error('═══════════════════════════════════════');
      console.error('❌ Error loading XML annotations:', error);
      console.error('═══════════════════════════════════════');
      // Create empty document on error
      const parser = new DOMParser();
      this.xmlDoc = parser.parseFromString('<?xml version="1.0" encoding="UTF-8"?><annotations></annotations>', 'application/xml');
    }
  }

  // Render XML overlay on current page (called each time page changes)
  loadAndRenderXmlOverlay(xmlUrl: string, pageViewport: any): void {
    if (!this.overlaySvg) {
      console.warn('⚠️ SVG overlay element not ready');
      return;
    }

    const svg = this.overlaySvg.nativeElement;
    svg.innerHTML = ''; // Clear previous overlays

    // Set SVG size same as page viewport
    svg.setAttribute('width', pageViewport.width.toString());
    svg.setAttribute('height', pageViewport.height.toString());
    
    // 🔍 DEBUG: Log SVG setup
    // console.log('🔍 SVG Setup Debug:');
    // console.log(`  SVG size: ${pageViewport.width} x ${pageViewport.height}`);
    // console.log(`  SVG position: absolute, top: 0, left: 0`);
    // console.log(`  SVG z-index: 20`);

    // // 🔍 DEBUG: Add a test rectangle to verify SVG is working
    // const testRect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    // testRect.setAttribute('x', '10');
    // testRect.setAttribute('y', '10');
    // testRect.setAttribute('width', '100');
    // testRect.setAttribute('height', '50');
    // testRect.setAttribute('fill', 'blue');
    // testRect.setAttribute('stroke', 'red');
    // testRect.setAttribute('stroke-width', '2');
    // svg.appendChild(testRect);
    // console.log('🔍 Added test rectangle to SVG');

    // Render annotations from XML if available
    if (this.xmlDoc) {
      this.renderXmlAnnotations(pageViewport);
    } else {
      console.warn('⚠️ No XML document loaded yet');
    }
  }

  // Render annotations from the loaded XML document
  renderXmlAnnotations(pageViewport: any): void {
    if (!this.xmlDoc) return;

    const svg = this.overlaySvg.nativeElement;
    
    // Helper for coordinate flipping
    const flipY = (y: number, height: number) => height - y;

    const drawRect = (node: Element) => {
      const x = +node.getAttribute('x')!;
      const y = +node.getAttribute('y')!;
      const width = +node.getAttribute('width')!;
      const height = +node.getAttribute('height')!;
      const color = node.getAttribute('color') || 'green';
      const pageHeight = pageViewport.height;
      const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', `${x}`);
      rect.setAttribute('y', `${flipY(y + height, pageHeight)}`);
      rect.setAttribute('width', `${width}`);
      rect.setAttribute('height', `${height}`);
      rect.setAttribute('stroke', color);
      rect.setAttribute('fill', 'none');
      rect.setAttribute('stroke-width', '1');
      svg.appendChild(rect);
    };

    const drawHighlight = (node: Element) => {
      const x1 = +node.getAttribute('x1')!;
      const y1 = +node.getAttribute('y1')!;
      const x2 = +node.getAttribute('x2')!;
      const y2 = +node.getAttribute('y2')!;
      const color = node.getAttribute('color') || 'rgba(255,255,0,0.4)';
      const pageHeight = pageViewport.height;
      // ✅ FIX: Convert PDF coordinates to viewport coordinates using current scale
      const [viewportX1, viewportY1] = pageViewport.convertToViewportPoint(x1, y1);
      const [viewportX2, viewportY2] = pageViewport.convertToViewportPoint(x2, y2);
      
      // 🔍 DEBUG: Log coordinate conversion
      console.log('🔍 Coordinate Debug:');
      console.log(`  PDF coords: (${x1}, ${y1}) to (${x2}, ${y2})`);
      console.log(`  Viewport coords: (${viewportX1.toFixed(2)}, ${viewportY1.toFixed(2)}) to (${viewportX2.toFixed(2)}, ${viewportY2.toFixed(2)})`);
      console.log(`  Page height: ${pageHeight}`);
      console.log(`  SVG size: ${pageViewport.width} x ${pageHeight}`);
      
      // ✅ FIX: Calculate proper rectangle dimensions
      const rectX = Math.min(viewportX1, viewportX2);
      const rectY = Math.min(viewportY1, viewportY2);
      const rectWidth = Math.abs(viewportX2 - viewportX1);
      const rectHeight = Math.abs(viewportY2 - viewportY1);
      
      const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', `${rectX}`);
      rect.setAttribute('y', `${flipY(rectY + rectHeight, pageHeight)}`);
      rect.setAttribute('width', `${rectWidth}`);
      rect.setAttribute('height', `${rectHeight}`);
      rect.setAttribute('fill', color);
      // rect.setAttribute('stroke', 'yellow');
      // rect.setAttribute('stroke-width', '1');
      svg.appendChild(rect);
      console.log(`  Final rect: x=${rectX}, y=${flipY(rectY + rectHeight, pageHeight)}, w=${rectWidth}, h=${rectHeight}`);
    };

    const drawText = (node: Element) => {
      const x = +node.getAttribute('x')!;
      const y = +node.getAttribute('y')!;
      const textContent = node.textContent || '';
      const color = node.getAttribute('color') || 'blue';
      const pageHeight = pageViewport.height;
      
      // ✅ FIX: Convert PDF coordinates to viewport coordinates using current scale
      const [viewportX, viewportY] = pageViewport.convertToViewportPoint(x, y);
      
      const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      text.setAttribute('x', `${viewportX}`);
      text.setAttribute('y', `${flipY(viewportY, pageHeight)}`);
      text.setAttribute('fill', color);
      text.setAttribute('font-size', '10px');
      text.textContent = textContent;
      svg.appendChild(text);
    };

    // Loop through all XML elements and filter by current page
    const allHighlights = Array.from(this.xmlDoc.getElementsByTagName('highlight'));
    const allRects = Array.from(this.xmlDoc.getElementsByTagName('rect'));
    const allTexts = Array.from(this.xmlDoc.getElementsByTagName('text'));
    
    // Filter by current page number
    const highlights = allHighlights.filter(element => {
      const page = element.getAttribute('page');
      return page ? parseInt(page) === this.pageNumber : false;
    });
    const rects = allRects.filter(element => {
      const page = element.getAttribute('page');
      return page ? parseInt(page) === this.pageNumber : false;
    });
    const texts = allTexts.filter(element => {
      const page = element.getAttribute('page');
      return page ? parseInt(page) === this.pageNumber : false;
    });
    
    console.log('───────────────────────────────────────');
    console.log('XML Elements Found:');
    console.log('  All Highlights:', allHighlights.length);
    console.log('  All Rectangles:', allRects.length);
    console.log('  All Text Elements:', allTexts.length);
    console.log('  Current Page Highlights:', highlights.length);
    console.log('  Current Page Rectangles:', rects.length);
    console.log('  Current Page Text Elements:', texts.length);
    console.log(`Current Page: ${this.pageNumber}, Scale: ${this.currentScale}`);
    
    highlights.forEach(drawHighlight);
    rects.forEach(drawRect);
    texts.forEach(drawText);
    
    console.log('✅ XML annotations rendered successfully');
    console.log(`Total SVG children: ${svg.children.length}`);
    console.log('═══════════════════════════════════════');
  }

  async renderPage(pageNum: number): Promise<void> {
    if (!this.pdfDoc) return;

    try {
      const page = await this.pdfDoc.getPage(pageNum);
      this.currentPage = page;
      
      // Apply rotation to viewport
      const viewport = page.getViewport({ 
        scale: this.currentScale,
        rotation: this.currentRotation 
      });
      
      // Get canvas references
      const canvas = this.pdfCanvas?.nativeElement;
      const cropCanvas = this.cropCanvas?.nativeElement;
      
      if (!canvas) {
        console.warn('PDF canvas not ready');
        return;
      }

      const context = canvas.getContext('2d');
      canvas.width = viewport.width;
      canvas.height = viewport.height;

      // Render PDF page
      const renderContext = {
        canvasContext: context,
        viewport: viewport
      };

      await page.render(renderContext).promise;
      console.log(`Page ${pageNum} rendered (scale: ${this.currentScale}, rotation: ${this.currentRotation}°)`);

      // Set up crop canvas overlay
      if (cropCanvas) {
        cropCanvas.width = viewport.width;
        cropCanvas.height = viewport.height;
        // Clear previous event listeners
        this.clearCanvasListeners(cropCanvas);
        this.addDrawingListeners(cropCanvas, pageNum, viewport);
        
        // Xml Overlay
        this.loadAndRenderXmlOverlay('images/building_drawing.xml', viewport);
        
        // Redraw highlights for this page
        // this.drawHighlights();
      }
    } catch (error) {
      console.error('Error rendering page:', error);
    }
  }

  private clearCanvasListeners(canvas: HTMLCanvasElement): void {
    // Remove existing listeners if any
    const listeners = this.canvasEventListeners.get(canvas);
    if (listeners) {
      canvas.removeEventListener('pointerdown', listeners.pointerdown);
      canvas.removeEventListener('contextmenu', listeners.contextmenu);
      // Remove click listener if it exists
      if (listeners.click) {
        canvas.removeEventListener('click', listeners.click);
      }
      this.canvasEventListeners.delete(canvas);
    }
  }

  private addDrawingListeners(canvas: HTMLCanvasElement, pageNumber: number, viewport: any): void {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.style.touchAction = 'none';
    canvas.style.cursor = 'crosshair'; // Set crosshair cursor

    // Create event handlers
    const contextmenuHandler = (e: Event) => e.preventDefault();

    // Add click handler for applying selected button to PDF location
    const onCanvasClick = (e: MouseEvent) => {
      e.preventDefault();
      
      // Check if a button is selected
      if (!this.selectedButtonId) {
        console.log('No button selected. Click a button first to select it.');
        return;
      }
      
      // Get canvas bounding rect - use the crop canvas that received the click
      const rect = canvas.getBoundingClientRect();
      
      // Calculate position relative to canvas
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      // Convert to PDF coordinates using viewport
      if (viewport && this.currentPage) {
        const [pdfX, pdfY] = viewport.convertToPdfPoint(x, y);
        
        // Flip the Y-axis to make (0,0) at top-left
        const topLeftY = this.currentPage.view[3] - pdfY;
        
        console.log('═══════════════════════════════════════');
        console.log(`📍 Applying Selected Button: ${this.selectedButtonId}`);
        console.log(`PDF Coordinates: X: ${pdfX.toFixed(2)}, Y: ${topLeftY.toFixed(2)}, Page: ${pageNumber}`);
        console.log('═══════════════════════════════════════');
        
        // Call API to get text and bboxes for the selected button
        this.extractTextAtLocation(pdfX, topLeftY, pageNumber, this.selectedButtonId);
      }
    };

    let isDrawing = false;
    let startX = 0, startY = 0;

    const onPointerDown = (e: PointerEvent) => {
      //  left-click (button 0)
      if (e.button !== 0) return;
      e.preventDefault();
      e.stopPropagation(); // Prevent event bubbling
      
      const bounds = canvas.getBoundingClientRect();
      const x = e.clientX - bounds.left;
      const y = e.clientY - bounds.top;
      startX = x;
      startY = y;
      isDrawing = true;
      canvas.classList.add('cropping-mode');
      canvas.style.pointerEvents = 'auto';

      // Add global listeners for pointer events
      const onPointerMove = (e: PointerEvent) => {
        if (!isDrawing) return;
        e.preventDefault();
        const bounds = canvas.getBoundingClientRect();
        const x = e.clientX - bounds.left;
        const y = e.clientY - bounds.top;

        // Clear canvas and redraw existing crops
        // this.redrawPageCrops(pageNumber);

        // Draw current selection rectangle
        ctx.strokeStyle = 'black'; // Use black for active drawing
        ctx.lineWidth = 1;
        ctx.setLineDash([5, 5]); // Dashed line for active selection
        ctx.strokeRect(
          Math.min(startX, x),
          Math.min(startY, y),
          Math.abs(x - startX),
          Math.abs(y - startY)
        );
        ctx.setLineDash([]); // Reset line dash
      };

      const onPointerUp = (e: PointerEvent) => {
        if (e.button !== 0 || !isDrawing) return;
        e.preventDefault();
        isDrawing = false;
        canvas.classList.remove('cropping-mode');
        const bounds = canvas.getBoundingClientRect();
        const endX = e.clientX - bounds.left;
        const endY = e.clientY - bounds.top;

        // Only create crop rectangle if there's meaningful area (minimum 10x10 pixels)
        const width = Math.abs(endX - startX);
        const height = Math.abs(endY - startY);

        if (width > 10 && height > 10) {
          const rect = {
            x: Math.min(startX, endX),
            y: Math.min(startY, endY),
            width: width,
            height: height
          };

          // Store and process the crop rectangle
          const pageRects = this.pageCropRects.get(pageNumber) || [];
          pageRects.push(rect);
          this.pageCropRects.set(pageNumber, pageRects);
          // this.redrawPageCrops(pageNumber);
          // this.addCropRectangle(rect, pageNumber);
        } else {
          // If rectangle is too small, just redraw existing crops
          // this.redrawPageCrops(pageNumber);
        }

        // Remove global listeners
        window.removeEventListener('pointermove', onPointerMove, true);
        window.removeEventListener('pointerup', onPointerUp, true);

        // Remove from our tracking
        this.globalEventListeners = this.globalEventListeners.filter(
          listener => listener.handler !== onPointerMove && listener.handler !== onPointerUp
        );
      };

      // Add global listeners and track them
      window.addEventListener('pointermove', onPointerMove, true);
      window.addEventListener('pointerup', onPointerUp, true);

      this.globalEventListeners.push(
        { element: window, event: 'pointermove', handler: onPointerMove as EventListener },
        { element: window, event: 'pointerup', handler: onPointerUp as EventListener }
      );
    };

    // Add event listeners to canvas and track them
    canvas.addEventListener('click', onCanvasClick);
    canvas.addEventListener('pointerdown', onPointerDown);
    canvas.addEventListener('contextmenu', contextmenuHandler);

    // Store listeners for cleanup
    this.canvasEventListeners.set(canvas, {
      pointerdown: onPointerDown,
      contextmenu: contextmenuHandler,
      click: onCanvasClick
    });
  }

  // PDF Error handling
  onPdfLoadError(error: any): void {
    console.error('PDF Load Error:', error);
    alert('Failed to load PDF. Please check:\n1. URL is accessible\n2. CORS is properly configured\n3. File exists at the path');
  }

  onPdfLoaded(event: any): void {
    console.log('PDF Loaded successfully:', event);
  }

ngOnInit(): void {
  console.log('DetectionComponent ngOnInit called');
  console.log('Initial PDF URL:', this.pdfUrl);
  // this.dashboardService.setComponentLoading('detection', true);
  // Listen for project changes from header component
  window.addEventListener('dashboardHeaderEvent', this.handleHeaderEvent.bind(this));
  
  // this.pdfNav.state$.subscribe(state => {
  //   console.log('PdfNav state received:', state);
  //   if (state.url && state.url !== this.pdfUrl) {
  //     // Only reload PDF if the URL changed and is not empty
  //     console.log('Updating PDF URL from:', this.pdfUrl, 'to:', state.url);
  //     this.pdfUrl = state.url;
  //     this.pageNumber = state.page || 1;
  //     // Reload the PDF with new URL
  //     this.loadPdf();
  //   } else if (state.page && state.page !== this.pageNumber) {
  //     // Same PDF: only update page
  //     this.pageNumber = state.page || 1;
  //     console.log('Updating page to:', this.pageNumber);
  //     this.renderPage(this.pageNumber);
  //   }
  //   this.isLoading = state.isLoading || false;
  //   this.dashboardService.setComponentLoading('detection', false);
  // });

  // this.widgetData.subscribe(data => {
  //   console.log('DetectionComponent received data:', data);
  //   this.data = data;
  // });

  this.updatePanelPositions();
  this.initializeCheckboxGroupPosition();
}

  navigateToPage(pageNumber: number): void {
    if (this.pdfDoc && pageNumber >= 1 && pageNumber <= this.pdfDoc.numPages) {
      this.pageNumber = pageNumber;
      this.renderPage(pageNumber);
    }
  }

  initializeCheckboxGroupPosition(): void {
    // Set initial position at top left
    this.checkboxGroupPosition.x = 80; // 20px from left edge
    // this.checkboxGroupPosition.y = 20; // 20px from top
  }

  onCheckboxChange(type: string, event: any): void {
    console.log(`${type} checkbox changed:`, event.target.checked);
    // Update panel positions when checkboxes change
    setTimeout(() => {
      this.updatePanelPositions();
    }, 10); // Small delay to allow checkbox state to update
  }

  // Update panel positions based on visible checkboxes
  updatePanelPositions(): void {
    const categories = ['site', 'building', 'door', 'frame', 'hw', 'ta', 'legend'];
    const visibleCategories = categories.filter(cat => this.checkboxes[cat as keyof typeof this.checkboxes]);
    
    const startX = 8;
    const startY = 40;
    const panelSpacing = 60; // Space between panels horizontally
    
    visibleCategories.forEach((category, index) => {
      this.panelPositions[category as keyof typeof this.panelPositions] = {
        x: startX + (index * panelSpacing),
        y: startY
      };
    });
  }

  // Helper methods for template
  trackByButtonId(index: number, button: ButtonConfig): string {
    return button.id;
  }

  getButtonTooltip(buttonId: string): string {
    const tooltips: { [key: string]: string } = {
      // Door tooltips
      'swing': 'Swing Door',
      'bypass': 'By-pass Door', 
      'bifold': 'Bi-fold Door',
      'pocket': 'Pocket Door',
      // TA tooltips
      'ta1': 'TA Option 1',
      'ta2': 'TA Option 2',
      'ta3': 'TA Option 3', 
      'ta4': 'TA Option 4',
      // Room tooltips
      'room1': 'Room Type 1',
      'room2': 'Room Type 2',
      'room3': 'Room Type 3',
      'room4': 'Room Type 4',
      // Bathroom tooltips
      'bath1': 'Bathroom Type 1',
      'bath2': 'Bathroom Type 2', 
      'bath3': 'Bathroom Type 3',
      'bath4': 'Bathroom Type 4'
    };
    return tooltips[buttonId] || buttonId;
  }

  getButtonTitle(buttonId: string): string {
    const titles: { [key: string]: string } = {
      // Door titles
      'swing': 'Swing Door - Traditional hinged door that opens inward or outward',
      'bypass': 'By-pass Door - Sliding door that moves along a track',
      'bifold': 'Bi-fold Door - Door that folds in half when opened',
      'pocket': 'Pocket Door - Sliding door that disappears into wall cavity',
      // TA titles
      'ta1': 'TA Option 1 - First TA configuration',
      'ta2': 'TA Option 2 - Second TA configuration', 
      'ta3': 'TA Option 3 - Third TA configuration',
      'ta4': 'TA Option 4 - Fourth TA configuration',
      // Room titles
      'room1': 'Room Type 1 - Standard room configuration',
      'room2': 'Room Type 2 - Alternative room layout',
      'room3': 'Room Type 3 - Special room design',
      'room4': 'Room Type 4 - Custom room setup',
      // Bathroom titles
      'bath1': 'Bathroom Type 1 - Standard bathroom layout',
      'bath2': 'Bathroom Type 2 - Compact bathroom design',
      'bath3': 'Bathroom Type 3 - Luxury bathroom configuration', 
      'bath4': 'Bathroom Type 4 - Accessible bathroom setup'
    };
    return titles[buttonId] || buttonId;
  }

  onSwingClick(): void {
    console.log('Swing button clicked');
    // Add your functionality here
  }

  onBypassClick(): void {
    console.log('By-pass button clicked');
    // Add your functionality here
  }

  onBifoldClick(): void {
    console.log('Bi-fold button clicked');
    // Add your functionality here
  }

  onBarnClick(): void {
    console.log('Barn button clicked');
    // Add your functionality here
  }

  // TA button methods
  onTA1Click(): void {
    console.log('TA1 button clicked');
    // Add your functionality here
  }

  onTA2Click(): void {
    console.log('TA2 button clicked');
    // Add your functionality here
  }

  onTA3Click(): void {
    console.log('TA3 button clicked');
    // Add your functionality here
  }

  onTA4Click(): void {
    console.log('TA4 button clicked');
    // Add your functionality here
  }

  // Room button methods
  onRoom1Click(): void {
    console.log('Room1 button clicked');
    // Add your functionality here
  }

  onRoom2Click(): void {
    console.log('Room2 button clicked');
    // Add your functionality here
  }

  onRoom3Click(): void {
    console.log('Room3 button clicked');
    // Add your functionality here
  }

  onRoom4Click(): void {
    console.log('Room4 button clicked');
    // Add your functionality here
  }

  // Bathroom button methods
  onBath1Click(): void {
    console.log('Bath1 button clicked');
    // Add your functionality here
  }

  onBath2Click(): void {
    console.log('Bath2 button clicked');
    // Add your functionality here
  }

  onBath3Click(): void {
    console.log('Bath3 button clicked');
    // Add your functionality here
  }

  onBath4Click(): void {
    console.log('Bath4 button clicked');
    // Add your functionality here
  }

  // Smart interaction methods (combines drag and toggle)
  onSmartMouseDown(event: MouseEvent, category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls'): void {
    // Track interaction start
    this.smartInteractionStates[category].startTime = Date.now();
    this.smartInteractionStates[category].startPosition = { x: event.clientX, y: event.clientY };
    this.smartInteractionStates[category].hasMoved = false;

    // Start drag functionality
    this.draggingStates[category] = true;
    this.dragOffsets[category].x = event.clientX - this.panelPositions[category].x;
    this.dragOffsets[category].y = event.clientY - this.panelPositions[category].y;
    
    const moveHandler = (e: MouseEvent) => this.onSmartMouseMove(e, category);
    const upHandler = () => this.onSmartMouseUp(category, moveHandler, upHandler);
    
    document.addEventListener('mousemove', moveHandler);
    document.addEventListener('mouseup', upHandler);
    
    event.preventDefault();
  }

  onSmartMouseMove(event: MouseEvent, category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls'): void {
    if (this.draggingStates[category]) {
      const deltaX = Math.abs(event.clientX - this.smartInteractionStates[category].startPosition.x);
      const deltaY = Math.abs(event.clientY - this.smartInteractionStates[category].startPosition.y);
      
      // If moved more than 5 pixels, consider it a drag
      if (deltaX > 5 || deltaY > 5) {
        this.smartInteractionStates[category].hasMoved = true;
        
        // Calculate new position
        let newX = event.clientX - this.dragOffsets[category].x;
        let newY = event.clientY - this.dragOffsets[category].y;
        
        // Check for alignment with other panels
        const alignmentResult = this.checkAlignment(newX, newY, category);
        if (alignmentResult.snapped) {
          newX = alignmentResult.x;
          newY = alignmentResult.y;
        }
        
        // Update position
        this.panelPositions[category].x = newX;
        this.panelPositions[category].y = newY;
        
        // Ensure panel stays within bounds
        const panel = document.querySelector(`.component-actions-${category}`) as HTMLElement;
        const container = document.querySelector('.component-content') as HTMLElement;
        
        if (panel && container) {
          const containerRect = container.getBoundingClientRect();
          const panelRect = panel.getBoundingClientRect();
          
          // Keep panel within container bounds
          this.panelPositions[category].x = Math.max(0, Math.min(this.panelPositions[category].x, containerRect.width - panelRect.width));
          this.panelPositions[category].y = Math.max(0, Math.min(this.panelPositions[category].y, containerRect.height - panelRect.height));
        }
      }
    }
  }

  onSmartMouseUp(category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls', moveHandler: any, upHandler: any): void {
    this.draggingStates[category] = false;
    document.removeEventListener('mousemove', moveHandler);
    document.removeEventListener('mouseup', upHandler);
    
    // Hide alignment guides when drag ends
    this.hideAlignmentGuides();
    
    // If it wasn't a drag (no movement), treat it as a click for toggle
    if (!this.smartInteractionStates[category].hasMoved) {
      const timeDiff = Date.now() - this.smartInteractionStates[category].startTime;
      // Only toggle if it was a quick click (less than 200ms)
      if (timeDiff < 200) {
        this.toggleOrientation(category);
      }
    }
    
    // Reset interaction state
    this.smartInteractionStates[category].hasMoved = false;
  }

  onSmartClick(event: MouseEvent, category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls'): void {
    // Prevent click if it was part of a drag operation
    if (this.smartInteractionStates[category].hasMoved) {
      event.preventDefault();
      event.stopPropagation();
    }
  }

  // Original draggable functionality for individual panels (kept for reference)
  onPanelMouseDown(event: MouseEvent, category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend'): void {
    this.draggingStates[category] = true;
    this.dragOffsets[category].x = event.clientX - this.panelPositions[category].x;
    this.dragOffsets[category].y = event.clientY - this.panelPositions[category].y;
    
    const moveHandler = (e: MouseEvent) => this.onDocumentMouseMove(e, category);
    const upHandler = () => this.onDocumentMouseUp(category, moveHandler, upHandler);
    
    document.addEventListener('mousemove', moveHandler);
    document.addEventListener('mouseup', upHandler);
    
    event.preventDefault();
  }

  onDocumentMouseMove(event: MouseEvent, category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend'): void {
    if (this.draggingStates[category]) {
      this.panelPositions[category].x = event.clientX - this.dragOffsets[category].x;
      this.panelPositions[category].y = event.clientY - this.dragOffsets[category].y;
      
      // Ensure panel stays within bounds
      const panel = document.querySelector(`.component-actions-${category}`) as HTMLElement;
      const container = document.querySelector('.component-content') as HTMLElement;
      
      if (panel && container) {
        const containerRect = container.getBoundingClientRect();
        const panelRect = panel.getBoundingClientRect();
        
        // Keep panel within container bounds
        this.panelPositions[category].x = Math.max(0, Math.min(this.panelPositions[category].x, containerRect.width - panelRect.width));
        this.panelPositions[category].y = Math.max(0, Math.min(this.panelPositions[category].y, containerRect.height - panelRect.height));
      }
    }
  }

  onDocumentMouseUp(category: 'site' | 'building'| 'door' | 'frame' | 'hw' | 'ta' | 'legend', moveHandler: any, upHandler: any): void {
    this.draggingStates[category] = false;
    document.removeEventListener('mousemove', moveHandler);
    document.removeEventListener('mouseup', upHandler);
  }

  toggleOrientation(category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls'): void {
    this.orientationStates[category] = !this.orientationStates[category];
    console.log(`${category} panel orientation changed to:`, this.orientationStates[category] ? 'vertical' : 'horizontal');
  }

  getPanelStyle(category: 'site' | 'building' | 'door' | 'frame' | 'hw' | 'ta' | 'legend' | 'pdfControls'): any {
    return {
      left: this.panelPositions[category].x + 'px',
      top: this.panelPositions[category].y + 'px',
      cursor: this.draggingStates[category] ? 'grabbing' : 'grab'
    };
  }
  // Toggle PDF viewer visibility
  togglePdfViewer(): void {
    this.showPdfViewer = !this.showPdfViewer;
  }

  // Button selection methods
  onButtonClick(buttonId: string): void {
    console.log('Button clicked:', buttonId);
    
    // Toggle selection - if same button clicked, deselect; otherwise select new button
    if (this.selectedButtonId === buttonId) {
      this.selectedButtonId = null;
      console.log('Button deselected:', buttonId);
    } else {
      this.selectedButtonId = buttonId;
      console.log('Button selected:', buttonId);
    }
  }

  // Check if a button is currently selected
  isButtonSelected(buttonId: string): boolean {
    return this.selectedButtonId === buttonId;
  }

  // Get button name for display
  getButtonName(buttonId: string): string {
    // Search through all button groups to find the button name
    for (const category of Object.keys(this.buttonGroups)) {
      const buttons = this.buttonGroups[category as keyof typeof this.buttonGroups];
      const button = buttons.find(btn => btn.id === buttonId);
      if (button) {
        return button.name || button.label;
      }
    }
    return buttonId;
  }

onPdfZoomIn(): void {
  console.log('PDF Zoom In clicked');
  // Increase zoom by 5%
  this.currentScale = Math.min(this.currentScale + 0.10, 5.0); // Max 500%
  console.log(`Zoom increased to: ${(this.currentScale * 100).toFixed(0)}%`);
  this.renderPage(this.pageNumber);
}

onPdfZoomOut(): void {
  console.log('PDF Zoom Out clicked');
  // Decrease zoom by 5%
  this.currentScale = Math.max(this.currentScale - 0.10, 0.25); // Min 25%
  console.log(`Zoom decreased to: ${(this.currentScale * 100).toFixed(0)}%`);
  this.renderPage(this.pageNumber);
}

  onPdfRotateLeft(): void {
    console.log('PDF Rotate Left clicked');
    this.currentRotation = (this.currentRotation - 90 + 360) % 360;
    this.renderPage(this.pageNumber);
  }

  onPdfRotateRight(): void {
    console.log('PDF Rotate Right clicked');
    this.currentRotation = (this.currentRotation + 90) % 360;
    this.renderPage(this.pageNumber);
  }

  // Page Navigation Methods
  onFirstPage(): void {
    if (this.pageNumber > 1) {
      this.pageNumber = 1;
      this.renderPage(this.pageNumber);
    }
  }

  onPreviousPage(): void {
    if (this.pageNumber > 1) {
      this.pageNumber--;
      this.renderPage(this.pageNumber);
    }
  }

  onNextPage(): void {
    if (this.pageNumber < this.totalPages) {
      this.pageNumber++;
      this.renderPage(this.pageNumber);
    }
  }

  onLastPage(): void {
    if (this.pageNumber < this.totalPages) {
      this.pageNumber = this.totalPages;
      this.renderPage(this.pageNumber);
    }
  }

  onPageInputChange(): void {
    // Validate page number input
    let pageNum = parseInt(this.pageNumber.toString(), 10);
    
    if (isNaN(pageNum)) {
      pageNum = 1;
    }
    
    // Clamp to valid range
    pageNum = Math.max(1, Math.min(pageNum, this.totalPages));
    
    if (pageNum !== this.pageNumber) {
      this.pageNumber = pageNum;
      this.renderPage(this.pageNumber);
    }
  }

  // Additional Zoom Methods
  onZoomReset(): void {
    console.log('Reset Zoom to 100%');
    this.currentScale = 1.0;
    this.renderPage(this.pageNumber);
  }

  onZoomFitWidth(): void {
    console.log('Fit Width');
    // Calculate scale to fit width
    const canvas = this.pdfCanvas?.nativeElement;
    const container = document.querySelector('.pdf-scroll-container') as HTMLElement;
    
    if (canvas && container && this.currentPage) {
      const containerWidth = container.clientWidth - 40; // Account for padding
      const viewport = this.currentPage.getViewport({ scale: 1.0 });
      const scale = containerWidth / viewport.width;
      
      this.currentScale = Math.max(0.25, Math.min(scale, 5.0));
      console.log('Fit width scale:', this.currentScale);
      this.renderPage(this.pageNumber);
    }
  }

  // Zoom dropdown methods
  toggleZoomDropdown(): void {
    this.showZoomDropdown = !this.showZoomDropdown;
  }

  onZoomAutomatic(): void {
    this.currentScale = 1.0;
    this.showZoomDropdown = false;
    this.renderPage(this.pageNumber);
  }

  onZoomActualSize(): void {
    this.currentScale = 1.0;
    this.showZoomDropdown = false;
    this.renderPage(this.pageNumber);
  }

  onZoomPageFit(): void {
    this.onZoomFitWidth();
    this.showZoomDropdown = false;
  }

  onZoomPageWidth(): void {
    this.onZoomFitWidth();
    this.showZoomDropdown = false;
  }

  onZoomSet(scale: number): void {
    this.currentScale = scale;
    this.showZoomDropdown = false;
    this.renderPage(this.pageNumber);
  }

  // Additional PDF Controls Methods
  onPresentationMode(): void {
    console.log('Presentation Mode (Fullscreen) clicked');
    const element = document.documentElement;
    if (element.requestFullscreen) {
      element.requestFullscreen();
    } else if ((element as any).webkitRequestFullscreen) {
      (element as any).webkitRequestFullscreen();
    } else if ((element as any).msRequestFullscreen) {
      (element as any).msRequestFullscreen();
    }
  }

  onPrintPdf(): void {
    console.log('Print PDF clicked');
    if (this.pdfUrl) {
      // Open PDF in new window for printing
      const printWindow = window.open(this.pdfUrl, '_blank');
      if (printWindow) {
        printWindow.onload = () => {
          printWindow.print();
        };
      }
    } else {
      console.warn('No PDF URL available for printing');
    }
  }

  onDownloadPdf(): void {
    console.log('Download PDF clicked');
    if (this.pdfUrl) {
      // Create download link
      const link = document.createElement('a');
      link.href = this.pdfUrl;
      link.download = 'document.pdf';
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else {
      console.warn('No PDF URL available for download');
    }
  }

  onFitToWidth(): void {
    console.log('Fit to Width clicked');
    this.onZoomFitWidth();
  }

  // Checkbox group drag methods
  onCheckboxGroupMouseDown(event: MouseEvent): void {
    // Allow dragging from anywhere in the checkbox group
    this.isCheckboxGroupDragging = true;
    this.checkboxGroupDragOffset.x = event.clientX - this.checkboxGroupPosition.x;
    this.checkboxGroupDragOffset.y = event.clientY - this.checkboxGroupPosition.y;
    
    const moveHandler = (e: MouseEvent) => this.onCheckboxGroupMouseMove(e);
    const upHandler = () => this.onCheckboxGroupMouseUp(moveHandler, upHandler);
    
    document.addEventListener('mousemove', moveHandler);
    document.addEventListener('mouseup', upHandler);
    
    event.preventDefault();
  }

  onCheckboxGroupMouseMove(event: MouseEvent): void {
    if (this.isCheckboxGroupDragging) {
      this.checkboxGroupPosition.x = event.clientX - this.checkboxGroupDragOffset.x;
      this.checkboxGroupPosition.y = event.clientY - this.checkboxGroupDragOffset.y;
      
      // Keep group within viewport bounds
      const group = document.querySelector('.checkbox-group') as HTMLElement;
      if (group) {
        const groupRect = group.getBoundingClientRect();
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        
        // Ensure group stays within viewport with some padding
        const padding = 10; // 10px padding from edges
        this.checkboxGroupPosition.x = Math.max(padding, Math.min(this.checkboxGroupPosition.x, viewportWidth - groupRect.width - padding));
        this.checkboxGroupPosition.y = Math.max(padding, Math.min(this.checkboxGroupPosition.y, viewportHeight - groupRect.height - padding));
      }
    }
  }

  onCheckboxGroupMouseUp(moveHandler: any, upHandler: any): void {
    this.isCheckboxGroupDragging = false;
    document.removeEventListener('mousemove', moveHandler);
    document.removeEventListener('mouseup', upHandler);
  }

  getCheckboxGroupStyle(): any {
    return {
      left: this.checkboxGroupPosition.x + 'px',
      top: this.checkboxGroupPosition.y + 'px',
      cursor: this.isCheckboxGroupDragging ? 'grabbing' : 'grab'
    };
  }

  // Smart interaction methods for checkbox group (similar to panel controls)
  onCheckboxGroupSmartMouseDown(event: MouseEvent): void {
    // Track interaction start
    this.checkboxGroupSmartInteraction.startTime = Date.now();
    this.checkboxGroupSmartInteraction.startPosition = { x: event.clientX, y: event.clientY };
    this.checkboxGroupSmartInteraction.hasMoved = false;

    // Start drag functionality
    this.isCheckboxGroupDragging = true;
    this.checkboxGroupDragOffset.x = event.clientX - this.checkboxGroupPosition.x;
    this.checkboxGroupDragOffset.y = event.clientY - this.checkboxGroupPosition.y;
    
    const moveHandler = (e: MouseEvent) => this.onCheckboxGroupSmartMouseMove(e);
    const upHandler = () => this.onCheckboxGroupSmartMouseUp(upHandler, moveHandler);
    
    document.addEventListener('mousemove', moveHandler);
    document.addEventListener('mouseup', upHandler);
    
    event.preventDefault();
  }

  onCheckboxGroupSmartMouseMove(event: MouseEvent): void {
    if (this.isCheckboxGroupDragging) {
      const deltaX = Math.abs(event.clientX - this.checkboxGroupSmartInteraction.startPosition.x);
      const deltaY = Math.abs(event.clientY - this.checkboxGroupSmartInteraction.startPosition.y);
      
      // If moved more than 5 pixels, consider it a drag
      if (deltaX > 5 || deltaY > 5) {
        this.checkboxGroupSmartInteraction.hasMoved = true;
        
        // Perform drag
        this.checkboxGroupPosition.x = event.clientX - this.checkboxGroupDragOffset.x;
        this.checkboxGroupPosition.y = event.clientY - this.checkboxGroupDragOffset.y;
        
        // Keep group within viewport bounds
        const group = document.querySelector('.checkbox-group') as HTMLElement;
        if (group) {
          const groupRect = group.getBoundingClientRect();
          const viewportWidth = window.innerWidth;
          const viewportHeight = window.innerHeight;
          
          // Ensure group stays within viewport with padding
          const padding = 2;
          this.checkboxGroupPosition.x = Math.max(padding, Math.min(this.checkboxGroupPosition.x, viewportWidth - groupRect.width - padding));
          this.checkboxGroupPosition.y = Math.max(padding, Math.min(this.checkboxGroupPosition.y, viewportHeight - groupRect.height - padding));
        }
      }
    }
  }

  onCheckboxGroupSmartMouseUp(upHandler: any, moveHandler: any): void {
    this.isCheckboxGroupDragging = false;
    document.removeEventListener('mousemove', moveHandler);
    document.removeEventListener('mouseup', upHandler);
    
    // If it wasn't a drag (no movement), treat it as a click for toggle
    if (!this.checkboxGroupSmartInteraction.hasMoved) {
      const timeDiff = Date.now() - this.checkboxGroupSmartInteraction.startTime;
      // Only toggle if it was a quick click (less than 200ms)
      if (timeDiff < 200) {
        this.toggleCheckboxGroupOrientation();
      }
    }
    
    // Reset interaction state
    this.checkboxGroupSmartInteraction.hasMoved = false;
  }

  onCheckboxGroupSmartClick(event: MouseEvent): void {
    // Prevent click if it was part of a drag operation
    if (this.checkboxGroupSmartInteraction.hasMoved) {
      event.preventDefault();
      event.stopPropagation();
    }
  }

  toggleCheckboxGroupOrientation(): void {
    this.checkboxGroupOrientation = !this.checkboxGroupOrientation;
    console.log('Checkbox group orientation changed to:', this.checkboxGroupOrientation ? 'vertical' : 'horizontal');
  }

  // Alignment and snapping methods
  checkAlignment(newX: number, newY: number, currentCategory: string): { snapped: boolean, x: number, y: number } {
    const categories = ['site', 'building', 'door', 'frame', 'hw', 'ta', 'legend'];
    const visibleCategories = categories.filter(cat => 
      this.checkboxes[cat as keyof typeof this.checkboxes] && cat !== currentCategory
    );
    
    let snappedX = newX;
    let snappedY = newY;
    let hasSnapped = false;
    
    // Check alignment with other visible panels
    for (const category of visibleCategories) {
      const otherPanel = this.panelPositions[category as keyof typeof this.panelPositions];
      
      // Check horizontal alignment (same Y position)
      if (Math.abs(newY - otherPanel.y) < this.alignmentGuides.snapThreshold) {
        snappedY = otherPanel.y;
        hasSnapped = true;
      }
      
      // Check vertical alignment (same X position)
      if (Math.abs(newX - otherPanel.x) < this.alignmentGuides.snapThreshold) {
        snappedX = otherPanel.x;
        hasSnapped = true;
      }
      
      // Check for stacking (horizontal: same Y, different X)
      if (Math.abs(newY - otherPanel.y) < this.alignmentGuides.snapThreshold) {
        // Suggest horizontal stacking positions
        const stackSpacing = 60; // Space between stacked panels
        const suggestedX = otherPanel.x + stackSpacing;
        if (Math.abs(newX - suggestedX) < this.alignmentGuides.snapThreshold) {
          snappedX = suggestedX;
          snappedY = otherPanel.y;
          hasSnapped = true;
        }
      }
      
      // Check for stacking (vertical: same X, different Y)
      if (Math.abs(newX - otherPanel.x) < this.alignmentGuides.snapThreshold) {
        // Suggest vertical stacking positions
        const stackSpacing = 40; // Space between vertically stacked panels
        const suggestedY = otherPanel.y + stackSpacing;
        if (Math.abs(newY - suggestedY) < this.alignmentGuides.snapThreshold) {
          snappedX = otherPanel.x;
          snappedY = suggestedY;
          hasSnapped = true;
        }
      }
    }
    
    // Update alignment guides for visual feedback
    this.updateAlignmentGuides(newX, newY, currentCategory, visibleCategories);
    
    return { snapped: hasSnapped, x: snappedX, y: snappedY };
  }

  updateAlignmentGuides(newX: number, newY: number, currentCategory: string, visibleCategories: string[]): void {
    this.alignmentGuides.horizontal = [];
    this.alignmentGuides.vertical = [];
    
    // Add alignment lines for other panels
    for (const category of visibleCategories) {
      const otherPanel = this.panelPositions[category as keyof typeof this.panelPositions];
      
      // Add horizontal alignment line if close to other panel's Y position
      if (Math.abs(newY - otherPanel.y) < this.alignmentGuides.snapThreshold * 2) {
        this.alignmentGuides.horizontal.push(otherPanel.y);
      }
      
      // Add vertical alignment line if close to other panel's X position
      if (Math.abs(newX - otherPanel.x) < this.alignmentGuides.snapThreshold * 2) {
        this.alignmentGuides.vertical.push(otherPanel.x);
      }
    }
    
    this.alignmentGuides.show = this.alignmentGuides.horizontal.length > 0 || this.alignmentGuides.vertical.length > 0;
  }

  hideAlignmentGuides(): void {
    this.alignmentGuides.show = false;
    this.alignmentGuides.horizontal = [];
    this.alignmentGuides.vertical = [];
  }

  // Removed drag and drop functionality - now using click-to-select mode

  async extractTextAtLocation(
    x: number,
    y: number,
    pageNumber: number,
    buttonId: string,
  ): Promise<void> {
    try {
      const relativePath = this.pdfUrl.split("orionprojects")[1];
      const trimmedPath = `orionprojects${relativePath}`;
      const requestBody = { 
        pdf_file_path: trimmedPath,
        x, y, page: pageNumber, buttonId };
      console.log('Making API call with:', requestBody);
  
      // ✅ Replace the mock API call with actual dashboardService call
      // const response = await lastValueFrom(
        // this.dashboardService.getTextonDrop(requestBody)
      // );
  
      // const data = {
      //   text: 'SITE AERIAL VIEW',
      //   bboxes: [
      //     [
      //       512.4630737304688,
      //       920.10400390625,
      //       868.1580810546875,
      //       974.5806274414062,
      //     ],
      //   ],
      // };
  
      // console.log('Service Response:', response);
  
      // ✅ Highlight the extracted text if bounding boxes are available
      // if (response?.data?.data?.bboxes?.length > 0) {
      //   const bboxes = typeof response?.data?.data?.bboxes[0] === 'number' 
      //     ? [response?.data?.data?.bboxes] 
      //     : response?.data?.data?.bboxes;
      //   this.highlightTextRegions(pageNumber, bboxes, response?.data?.data.text, buttonId);
      // } else {
      //   console.warn('No bounding boxes returned from API. Creating manual rectangle.');
      //   // Create manual rectangle when no text is found
      //   this.createManualRectangle(x, y, pageNumber, buttonId);
      // }
  
    } catch (error) {
      console.error('Error extracting text or loading projects:', error);
    }
  }

  // Create manual rectangle when no text is found
  createManualRectangle(x: number, y: number, pageNumber: number, buttonId: string): void {
    const rectangleId = `manual_rect_${this.nextRectangleId++}`;
    const defaultSize = 100; // Default rectangle size
    
    // Use the same coordinate conversion logic as canvas click handler
    if (this.currentPage) {
      // Apply the same Y-axis flip as the canvas click handler
      const topLeftY = this.currentPage.view[3] - y;
      
      // Convert PDF coordinates to viewport coordinates for display
      const viewport = this.currentPage.getViewport({ scale: this.currentScale });
      const [viewportX, viewportY] = viewport.convertToViewportPoint(x, topLeftY);
      
      const rectangle = {
        id: rectangleId,
        x: viewportX - defaultSize / 2, // Center the rectangle on click point
        y: viewportY - defaultSize / 2,
        width: defaultSize,
        height: defaultSize,
        buttonId: buttonId,
        pageNumber: pageNumber,
        isAdjusting: false,
        showControls: true
      };
      
      this.manualRectangles.set(rectangleId, rectangle);
      console.log('Created manual rectangle at PDF coords:', { x, y });
      console.log('Flipped Y coord:', topLeftY);
      console.log('Converted to viewport coords:', { viewportX, viewportY });
      console.log('Rectangle positioned at:', { x: rectangle.x, y: rectangle.y });
    } else {
      console.warn('No current page available for coordinate conversion');
    }
  }

  // Remove manual rectangle
  removeManualRectangle(rectangleId: string): void {
    this.manualRectangles.delete(rectangleId);
    console.log('Removed manual rectangle:', rectangleId);
  }

  // Save manual rectangle to XML
  saveManualRectangle(rectangleId: string): void {
    const rectangle = this.manualRectangles.get(rectangleId);
    if (!rectangle) return;

    // Convert viewport coordinates back to PDF coordinates
    const viewport = this.currentPage.getViewport({ scale: this.currentScale });
    const [pdfX1, pdfY1] = viewport.convertToPdfPoint(rectangle.x, rectangle.y);
    const [pdfX2, pdfY2] = viewport.convertToPdfPoint(
      rectangle.x + rectangle.width, 
      rectangle.y + rectangle.height
    );

    // Create bbox array in PDF coordinates
    const bbox = [pdfX1, pdfY1, pdfX2, pdfY2];
    
    // Add to XML using existing method with page number
    this.highlightTextRegions(rectangle.pageNumber, [bbox], 'Manual Rectangle', rectangle.buttonId);
    
    // Hide controls after saving
    rectangle.showControls = false;
    this.manualRectangles.set(rectangleId, rectangle);
    
    console.log('Saved manual rectangle to XML for page:', rectangle.pageNumber);
  }

  // Start adjusting rectangle (for dragging)
  startAdjustingRectangle(rectangleId: string, event: MouseEvent): void {
    // Check if the click is on a resize handle
    const target = event.target as HTMLElement;
    if (target.classList.contains('resize-handle')) {
      return; // Let the resize handle handle the event
    }

    const rectangle = this.manualRectangles.get(rectangleId);
    if (!rectangle) return;

    rectangle.isAdjusting = true;
    this.manualRectangles.set(rectangleId, rectangle);
    
    // Add global mouse move and up listeners for dragging
    const onMouseMove = (e: MouseEvent) => this.handleDrag(rectangleId, e);
    const onMouseUp = () => {
      this.stopAdjustingRectangle(rectangleId);
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };
    
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
    
    event.preventDefault();
    event.stopPropagation();
  }

  // Handle rectangle dragging
  handleDrag(rectangleId: string, event: MouseEvent): void {
    const rectangle = this.manualRectangles.get(rectangleId);
    if (!rectangle) return;

    const deltaX = event.movementX;
    const deltaY = event.movementY;

    rectangle.x += deltaX;
    rectangle.y += deltaY;

    this.manualRectangles.set(rectangleId, rectangle);
  }

  // Update rectangle position/size during adjustment
  updateRectangle(rectangleId: string, newX: number, newY: number, newWidth?: number, newHeight?: number): void {
    const rectangle = this.manualRectangles.get(rectangleId);
    if (!rectangle) return;

    rectangle.x = newX;
    rectangle.y = newY;
    if (newWidth !== undefined) rectangle.width = newWidth;
    if (newHeight !== undefined) rectangle.height = newHeight;
    
    this.manualRectangles.set(rectangleId, rectangle);
  }

  // Stop adjusting rectangle
  stopAdjustingRectangle(rectangleId: string): void {
    const rectangle = this.manualRectangles.get(rectangleId);
    if (!rectangle) return;

    rectangle.isAdjusting = false;
    this.manualRectangles.set(rectangleId, rectangle);
  }

  // Get rectangles for current page only
  getRectanglesForCurrentPage(): any[] {
    return Array.from(this.manualRectangles.values()).filter(
      rectangle => rectangle.pageNumber === this.pageNumber
    );
  }

  // Start resizing rectangle
  startResize(rectangleId: string, direction: string, event: MouseEvent): void {
    event.preventDefault();
    event.stopPropagation();
    
    const rectangle = this.manualRectangles.get(rectangleId);
    if (!rectangle) return;

    rectangle.isAdjusting = true;
    this.manualRectangles.set(rectangleId, rectangle);
    
    // Store initial mouse position for accurate resizing
    const startX = event.clientX;
    const startY = event.clientY;
    const startRect = { ...rectangle };
    
    // Add global mouse move and up listeners for resizing
    const onMouseMove = (e: MouseEvent) => this.handleResize(rectangleId, direction, e, startX, startY, startRect);
    const onMouseUp = () => {
      this.stopAdjustingRectangle(rectangleId);
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };
    
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  }

  // Handle rectangle resizing
  handleResize(rectangleId: string, direction: string, event: MouseEvent, startX: number, startY: number, startRect: any): void {
    const rectangle = this.manualRectangles.get(rectangleId);
    if (!rectangle) return;

    const deltaX = event.clientX - startX;
    const deltaY = event.clientY - startY;

    // Reset to original values
    rectangle.x = startRect.x;
    rectangle.y = startRect.y;
    rectangle.width = startRect.width;
    rectangle.height = startRect.height;

    switch (direction) {
      // Corner handles
      case 'nw': // North-west
        rectangle.x += deltaX;
        rectangle.y += deltaY;
        rectangle.width -= deltaX;
        rectangle.height -= deltaY;
        break;
      case 'ne': // North-east
        rectangle.y += deltaY;
        rectangle.width += deltaX;
        rectangle.height -= deltaY;
        break;
      case 'sw': // South-west
        rectangle.x += deltaX;
        rectangle.width -= deltaX;
        rectangle.height += deltaY;
        break;
      case 'se': // South-east
        rectangle.width += deltaX;
        rectangle.height += deltaY;
        break;
      
      // Mid-side handles
      case 'n': // North (top edge)
        rectangle.y += deltaY;
        rectangle.height -= deltaY;
        break;
      case 's': // South (bottom edge)
        rectangle.height += deltaY;
        break;
      case 'w': // West (left edge)
        rectangle.x += deltaX;
        rectangle.width -= deltaX;
        break;
      case 'e': // East (right edge)
        rectangle.width += deltaX;
        break;
    }

    // Ensure minimum size
    rectangle.width = Math.max(20, rectangle.width);
    rectangle.height = Math.max(20, rectangle.height);

    this.manualRectangles.set(rectangleId, rectangle);
  }

  // use to mark annotation on same pdf file
  // highlightTextRegions(pageNumber: number, bboxes: number[][], text: string, buttonId: string): void {
  //   // Get color based on button
  //   const color = this.getButtonHighlightColor(buttonId);
    
  //   // Store highlighted regions
  //   const pageRegions = this.highlightedRegions.get(pageNumber) || [];
    
  //   bboxes.forEach(bbox => {
  //     pageRegions.push({
  //       bbox: bbox,
  //       color: color,
  //       text: text,
  //       buttonId: buttonId
  //     });
  //   });
  //   this.highlightedRegions.set(pageNumber, pageRegions);
    
  //   // Redraw canvas with highlights
  //   this.drawHighlights();
  // }



  // use to mark annnotation on xml file 
highlightTextRegions(
  pageNumber: number,
  bboxes: number[][],
  detectedText: string,
  buttonId: string
) {
  if (!this.xmlDoc) {
    const parser = new DOMParser();
    this.xmlDoc = parser.parseFromString("<annotations></annotations>", "application/xml");
  }

  const svg = this.overlaySvg.nativeElement;
  const viewport = this.currentPage.getViewport({ scale: this.currentScale });
  const pageHeight = viewport.height;

  const flipY = (y: number) => pageHeight - y;

  for (const [x1, y1, x2, y2] of bboxes) {
    const colorMap: Record<string, string> = {
      site_building: "rgba(135, 123, 152, 0.4)",
      site: "rgba(255, 0, 0, 0.4)",

    // --- BUILDING ---rgb(195 190 92);
    building_floor: "rgba(195, 190, 92, 0.4)",
    building_room_name: "rgba(195, 190, 92, 0.4)",
    building_room_number: "rgba(195, 190, 92, 0.4)",
    building_unit_name: "rgba(195, 190, 92, 0.4)",
    building_unit_number: "rgba(195, 190, 92, 0.4)",
    building_unit_bath_name: "rgba(195, 190, 92, 0.4)",
    building_unit_bath_number: "rgba(195, 190, 92, 0.4)",
    building_opening_number: "rgba(195, 190, 92, 0.4)",
    building_wall_type: "rgba(195, 190, 92, 0.4)",
    building_ada: "rgba(195, 190, 92, 0.4)",
    building_connecting: "rgba(195, 190, 92, 0.4)",
    building_balcony: "rgba(195, 190, 92, 0.4)",
    building_ta_tag: "rgba(195, 190, 92, 0.4)",

    // --- DOOR ---
    single_swing: "rgba(90, 102, 98, 0.4)",
    double_swing: "rgba(90, 102, 98, 0.4)",
    double_bypass: "rgba(90, 102, 98, 0.4)",
    triple_bypass: "rgba(90, 102, 98, 0.4)",
    quad_bypass: "rgba(90, 102, 98, 0.4)",
    single_barn: "rgba(90, 102, 98, 0.4)",
    double_barn: "rgba(90, 102, 98, 0.4)",
    single_bifold: "rgba(90, 102, 98, 0.4)",
    double_bifold: "rgba(90, 102, 98, 0.4)",
    single_pocket: "rgba(90, 102, 98, 0.4)",
    double_pocket: "rgba(90, 102, 98, 0.4)",

    // --- FRAME ---  
    wrap_around: "rgba(101, 151, 132, 0.4)",
    butt: "rgba(101, 151, 132, 0.4)",

    // ---HW ---
    hw_set: "rgba(119, 140, 151, 0.4)",

      // building: "rgba(0, 255, 0, 0.4)",
      // door: "rgba(0, 0, 255, 0.4)",
      // frame: "rgba(255, 165, 0, 0.4)",
      // hw: "rgba(255, 0, 255, 0.4)",
      // ta: "rgba(0, 255, 255, 0.4)",
      // legend: "rgba(255, 255, 0, 0.4)"
    };

    const color = colorMap[buttonId] || "rgba(255, 255, 0, 0.4)";

    // 🧾 Add new highlight node to XML (store original PDF coordinates)
    const highlightNode = this.xmlDoc.createElement("highlight");
    highlightNode.setAttribute("page", pageNumber.toString());
    highlightNode.setAttribute("x1", x1.toFixed(2));
    highlightNode.setAttribute("y1", y1.toFixed(2));
    highlightNode.setAttribute("x2", x2.toFixed(2));
    highlightNode.setAttribute("y2", y2.toFixed(2));
    highlightNode.setAttribute("color", color);
    highlightNode.setAttribute("label", buttonId);
    highlightNode.setAttribute("text", detectedText || '');
    this.xmlDoc.documentElement.appendChild(highlightNode);

    // ✅ FIX: Convert PDF coordinates to viewport coordinates for display
    const [viewportX1, viewportY1] = viewport.convertToViewportPoint(x1, y1);
    const [viewportX2, viewportY2] = viewport.convertToViewportPoint(x2, y2);

    // ✅ FIX: Calculate proper rectangle dimensions
    const rectX = Math.min(viewportX1, viewportX2);
    const rectY = Math.min(viewportY1, viewportY2);
    const rectWidth = Math.abs(viewportX2 - viewportX1);
    const rectHeight = Math.abs(viewportY2 - viewportY1);

    // 🟨 Draw visible highlight using viewport coordinates
    const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    rect.setAttribute("x", `${rectX}`);
    rect.setAttribute("y", `${flipY(rectY + rectHeight)}`);
    rect.setAttribute("width", `${rectWidth}`);
    rect.setAttribute("height", `${rectHeight}`);
    rect.setAttribute("fill", color);
    // rect.setAttribute("stroke", "orange");
    // rect.setAttribute("stroke-width", "1");
    svg.appendChild(rect);

    // 🏷️ Optional: Add label text using viewport coordinates
    const labelText = document.createElementNS("http://www.w3.org/2000/svg", "text");
    labelText.setAttribute("x", `${rectX}`);
    labelText.setAttribute("y", `${flipY(rectY + rectHeight) - 5}`);
    labelText.setAttribute("fill", "black");
    labelText.setAttribute("font-size", "10px");
    labelText.textContent = detectedText;
    // svg.appendChild(labelText);
  }

  // 💾 Optional: save to backend or local file
  // this.saveXmlToServer(buttonId, detectedText);
}

saveXmlToServer(buttonControlId?: string, text?: string) {
  if (!this.xmlDoc) {
    console.warn('⚠️ No XML document to save');
    return;
  }

 const serializer = new XMLSerializer();
  const xmlString = serializer.serializeToString(this.xmlDoc);

  console.log('═══════════════════════════════════════');
  console.log('💾 Saving XML Annotations');
  console.log('───────────────────────────────────────');
  console.log('XML Content:');
  console.log(xmlString);
  console.log('Button Control ID:', buttonControlId);
  console.log('Text:', text);
  console.log('───────────────────────────────────────');

  // Extract PDF path from current PDF URL
  const pdfPath = this.pdfUrl ? this.pdfUrl.split("orionprojects")[1] : 'unknown.pdf';
  
  // Prepare payload with additional fields
  const payload: any = {
    pdfPath: pdfPath,
    xmlContent: xmlString,
  };

  // Add button control ID and text if provided
  if (buttonControlId && text) {
    payload.buttonControlId = buttonControlId;
    payload.text = text;
  }

  // Add project information from header
  if (this.projectId) {
    payload.projectId = parseInt(this.projectId, 10);
  }
  if (this.revisionId) {
    payload.revisionId = this.revisionId;
  }
  if (this.revisionNo) {
    payload.revisionNo = this.revisionNo;
  }

  // Option 1: Save to server (primary method)
  // this.dashboardService.saveXmlAnnotations(payload).subscribe({
  //   next: (response) => {
  //     console.log('✅ XML saved to server successfully:', response);
  //   },
  //   error: (err: any) => {
  //     console.error('❌ Error saving XML to server:', err);
  //     // Fallback: Download locally if server save fails
  //     console.log('📥 Falling back to local download...');
  //     this.downloadXmlFile(xmlString, 'building_drawing.xml');
  //   },
  // });

  // Option 2: Also download locally for backup/testing (uncomment if needed)
  // Uncomment the line below to also download XML locally for testing
  // this.downloadXmlFile(xmlString, 'building_drawing.xml');

  console.log('✅ XML save initiated');
  console.log('═══════════════════════════════════════');
}

// Helper method to download XML file
private downloadXmlFile(xmlContent: string, filename: string): void {
  const blob = new Blob([xmlContent], { type: 'application/xml' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  window.URL.revokeObjectURL(url);
  console.log(`📥 Downloaded ${filename}`);
}
  

  getButtonHighlightColor(buttonId: string): string {
    // Map button IDs to their highlight colors (light shades)
    const colorMap: { [key: string]: string } = {
      'site_building': 'rgba(109, 100, 122, 0.3)', // Light shade of #6d647a
      'building_floor': 'rgba(141, 137, 68, 0.3)',
      'building_room_name': 'rgba(141, 137, 68, 0.3)',
      'building_room_number': 'rgba(141, 137, 68, 0.3)',
      'building_unit_name': 'rgba(141, 137, 68, 0.3)',
      'building_unit_number': 'rgba(141, 137, 68, 0.3)',
      'building_unit_bath_name': 'rgba(141, 137, 68, 0.3)',
      'building_unit_bath_number': 'rgba(141, 137, 68, 0.3)',
      'building_opening_number': 'rgba(141, 137, 68, 0.3)',
      'building_wall_type': 'rgba(141, 137, 68, 0.3)',
      'building_ada': 'rgba(141, 137, 68, 0.3)',
      'building_connecting': 'rgba(141, 137, 68, 0.3)',
      'building_balcony': 'rgba(141, 137, 68, 0.3)',
      'building_ta_tag': 'rgba(141, 137, 68, 0.3)',
    };
    
    return colorMap[buttonId] || 'rgba(109, 100, 122, 0.3)';
  }

  drawHighlights(): void {
    const canvas = this.cropCanvas?.nativeElement;
    if (!canvas || !this.currentPage) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear the canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Get current page highlights
    const pageRegions = this.highlightedRegions.get(this.pageNumber) || [];

    
    const viewport = this.currentPage.getViewport({ 
      scale: this.currentScale,
      rotation: this.currentRotation 
    });
    
    // Draw each highlight
    pageRegions.forEach(region => {
      const [x1, y1, x2, y2] = region.bbox;
      
      // Convert PDF coordinates to canvas coordinates
      // Note: PDF uses bottom-left origin, we need to flip Y
      const pageHeight = this.currentPage.view[3];
      const canvasTopLeftY = pageHeight - y2;
      const canvasBottomRightY = pageHeight - y1;
      
      const [canvasX1, canvasY1] = viewport.convertToViewportPoint(x1, canvasTopLeftY);
      const [canvasX2, canvasY2] = viewport.convertToViewportPoint(x2, canvasBottomRightY);
      
      // Draw highlight rectangle
      ctx.fillStyle = region.color;
      ctx.fillRect(
        canvasX1,
        canvasY1,
        canvasX2 - canvasX1,
        canvasY2 - canvasY1
      );
      
      // Optional: Draw border
      ctx.strokeStyle = region.color.replace('0.3', '0.6'); // Darker border
      ctx.lineWidth = 1;
      ctx.strokeRect(
        canvasX1,
        canvasY1,
        canvasX2 - canvasX1,
        canvasY2 - canvasY1
      );
    });
    
    console.log(`Drew ${pageRegions.length} highlights on page ${this.pageNumber}`);
  }
  // Handle events from header component
  private handleHeaderEvent = (event: Event): void => {
    const customEvent = event as CustomEvent;
    const { eventType, data } = customEvent.detail;

    if (eventType === 'projectChanged') {
      console.log('Detection component received project change:', data);
      this.projectId = data.projectId || '';
      this.projectNumber = data.projectNumber || '';
      
      // You can also update revision info if needed
      // this.revisionId = data.revisionId || 1;
      // this.revisionNo = data.revisionNo || 1;
      
      console.log('Updated project info:', {
        projectId: this.projectId,
        projectNumber: this.projectNumber
      });
    }
  }

  ngOnDestroy(): void {
    // Remove event listener
    window.removeEventListener('dashboardHeaderEvent', this.handleHeaderEvent.bind(this));
  }
}
