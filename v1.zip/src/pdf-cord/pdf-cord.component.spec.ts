import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PdfCordComponent } from './pdf-cord.component';

describe('PdfCordComponent', () => {
  let component: PdfCordComponent;
  let fixture: ComponentFixture<PdfCordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PdfCordComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PdfCordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
