import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer';

@Component({
  selector: 'app-pdf-cord',
  imports: [CommonModule, NgxExtendedPdfViewerModule],
  templateUrl: './pdf-cord.component.html',
  styleUrl: './pdf-cord.component.scss'
})
export class PdfCordComponent {

// Use local PDF for better performance and to avoid CORS issues
  pdfUrl = '/assets/test.pdf'; // Back to local PDF
  xmlUrl = 'assets/building_drawing.xml';
  initialZoom = 'page-width'; // default zoom mode
  isLoading = true;
  annotations: any[] = [];
  currentScale = 1;
  @ViewChild('annotationSvg', { static: false }) annotationSvg!: ElementRef<SVGSVGElement>;
  
  // PDF coordinate detection properties
  isCoordinateMode = false;
  pdfDocument: any = null;
  
  // Store event handlers for cleanup
  private clickHandlers: Map<HTMLElement, (event: MouseEvent) => void> = new Map();

 constructor(private http: HttpClient) {}


 async ngOnInit() {
    try {
      console.log('=== PDF Cord Component Initialization ===');
      console.log('PDF URL:', this.pdfUrl);
      console.log('XML URL:', this.xmlUrl);
      
      // Set loading to false immediately for faster UI
      this.isLoading = false;
      
      // Load XML annotations in background
      setTimeout(() => {
        this.loadXmlAnnotations();
      }, 100);
      
      console.log('✅ Component initialized successfully');
    } catch (error) {
      console.error('❌ Error in ngOnInit:', error);
      this.isLoading = false;
    }
  }
loadXmlAnnotations() {
    this.http.get(this.xmlUrl, { responseType: 'text' }).subscribe({
      next: (xmlText) => {
        try {
          const parser = new DOMParser();
          const xml = parser.parseFromString(xmlText, 'application/xml');
          this.annotations = Array.from(xml.getElementsByTagName('annotation')).map(node => ({
            page: +node.getAttribute('page')!,
            x: +node.getAttribute('x')!,
            y: +node.getAttribute('y')!,
            width: +node.getAttribute('width')!,
            height: +node.getAttribute('height')!,
            color: node.getAttribute('color') || '#f00'
          }));
          console.log('✅ XML annotations loaded:', this.annotations.length);
        } catch (error) {
          console.warn('⚠️ Error parsing XML annotations:', error);
          this.annotations = [];
        }
      },
      error: (error) => {
        console.warn('⚠️ Error loading XML annotations:', error);
        this.annotations = [];
      }
    });
  }

    async onPdfLoaded(event: any) {
    console.log('✅ PDF Loaded successfully:', event.pagesCount, 'pages');
    this.isLoading = false;
    this.pdfDocument = event.pdfDocument;
    console.log('PDF loading completed in:', performance.now(), 'ms');
    
    // Enable coordinate detection mode after a delay
    setTimeout(() => {
      this.enableCoordinateDetection();
    }, 2000); // Wait 2 seconds for PDF to fully render
  }

  //  async onPageRendered(event: any) {
  //   const pageNumber = event.pageNumber;
  //   const page = await this.pdfDoc.getPage(pageNumber);
  //   const viewport = page.getViewport({ scale: event.scale });

  //   const svg = this.annotationSvg.nativeElement;
  //   svg.innerHTML = ''; // Clear previous annotations

  //   const pageAnnotations = this.annotations.filter(a => a.page === pageNumber);
  //   for (const a of pageAnnotations) {
  //     const [vx, vy] = viewport.convertToViewportPoint(a.x, a.y);
  //     const scaledWidth = a.width * viewport.scale;
  //     const scaledHeight = a.height * viewport.scale;

  //     const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
  //     rect.setAttribute('x', vx.toString());
  //     rect.setAttribute('y', (viewport.height - vy - scaledHeight).toString());
  //     rect.setAttribute('width', scaledWidth.toString());
  //     rect.setAttribute('height', scaledHeight.toString());
  //     rect.setAttribute('class', 'annotation');
  //     rect.setAttribute('fill', a.color);
  //     rect.setAttribute('fill-opacity', '0.2');
  //     rect.setAttribute('stroke', a.color);
  //     rect.setAttribute('stroke-width', '1');
  //     svg.appendChild(rect);
  //   }
  // }

  async onPageRendered(event: any) {
    console.log('Page rendered:', event.pageNumber);
    // Simplified - just log for now
    // Annotations will be handled by ngx-extended-pdf-viewer
  }


  onZoomChanged(event: any) {
    console.log('Zoom changed:', event);
    this.currentScale = event.scale;
    console.log(`🔍 Current scale updated to: ${this.currentScale}`);
  }

  // Enable coordinate detection mode
  enableCoordinateDetection() {
    this.isCoordinateMode = true;
    console.log('🎯 Coordinate detection mode enabled - Click on PDF to get coordinates');
    
    // Add event listeners to PDF viewer with multiple attempts
    this.addCoordinateListeners();
  }

  // Add click and hover listeners to PDF
  addCoordinateListeners() {
    console.log('🔍 Looking for PDF viewer...');
    
    // Try multiple selectors to find PDF pages
    let pages: NodeListOf<Element> | null = null;
    
    // Try different selectors
    const selectors = [
      'ngx-extended-pdf-viewer .page',
      '.page',
      'canvas',
      '[data-page-number]'
    ];
    
    for (const selector of selectors) {
      pages = document.querySelectorAll(selector);
      if (pages.length > 0) {
        console.log(`✅ Found ${pages.length} PDF elements using selector: ${selector}`);
        break;
      }
    }
    
    if (!pages || pages.length === 0) {
      console.warn('⚠️ No PDF pages found, retrying in 1 second...');
      setTimeout(() => this.addCoordinateListeners(), 1000);
      return;
    }

    console.log(`🎯 Setting up coordinate detection for ${pages.length} pages`);

    pages.forEach((page: Element, index: number) => {
      const pageElement = page as HTMLElement;
      
      // Add crosshair cursor
      pageElement.style.cursor = 'crosshair';
      pageElement.style.pointerEvents = 'auto';
      
      // Remove existing listener if it exists
      const existingHandler = this.clickHandlers.get(pageElement);
      if (existingHandler) {
        pageElement.removeEventListener('click', existingHandler);
      }
      
      // Create new click handler
      const clickHandler = (event: MouseEvent) => {
        console.log('🖱️ Click detected on page element');
        this.handlePdfClick(event, index + 1);
      };
      
      // Store handler for cleanup
      this.clickHandlers.set(pageElement, clickHandler);
      
      // Add click listener
      pageElement.addEventListener('click', clickHandler);

      // Add hover effect
      pageElement.addEventListener('mouseenter', () => {
        pageElement.style.cursor = 'crosshair';
        console.log('🖱️ Mouse entered PDF page');
      });
      
      console.log(`✅ Set up coordinate detection for page ${index + 1}`);
    });
  }

  // Handle PDF click to get coordinates
  async handlePdfClick(event: MouseEvent, pageNumber: number) {
    console.log('🎯 PDF Click Handler Called');
    
    if (!this.isCoordinateMode) {
      console.log('⚠️ Coordinate mode is disabled');
      return;
    }

    event.preventDefault();
    event.stopPropagation();

    const target = event.target as HTMLElement;
    const rect = target.getBoundingClientRect();
    
    // Get click position relative to the page
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    console.log('🎯 PDF Click Detected:');
    console.log(`  Page: ${pageNumber}`);
    console.log(`  Click Position (relative to page): X=${x.toFixed(2)}, Y=${y.toFixed(2)}`);
    console.log(`  Page Size: ${rect.width} x ${rect.height}`);
    console.log(`  Target element:`, target.tagName, target.className);
    
    // Get PDF coordinates using PDF.js APIs
    try {
      if (this.pdfDocument) {
        console.log('📄 PDF Document available, getting page...');
        const page = await this.pdfDocument.getPage(pageNumber);
        
        // Always calculate coordinates at scale 1 (100% zoom) regardless of current zoom
        const baseViewport = page.getViewport({ scale: 1.0 });
        const currentViewport = page.getViewport({ scale: this.currentScale });
        
        console.log('🔍 Zoom Information:');
        console.log(`  Current Zoom Scale: ${this.currentScale}`);
        console.log(`  Base Scale (for coordinates): 1.0`);
        console.log(`  Current Viewport: ${currentViewport.width} x ${currentViewport.height}`);
        console.log(`  Base Viewport: ${baseViewport.width} x ${baseViewport.height}`);
        
        // Convert click coordinates from current zoom to base scale (1.0)
        const scaleRatio = this.currentScale;
        const normalizedX = x / scaleRatio;
        const normalizedY = y / scaleRatio;
        
        console.log('📐 Coordinate Normalization:');
        console.log(`  Click Position (zoomed): X=${x.toFixed(2)}, Y=${y.toFixed(2)}`);
        console.log(`  Normalized Position (scale 1): X=${normalizedX.toFixed(2)}, Y=${normalizedY.toFixed(2)}`);
        
        // Use base viewport for coordinate conversion
        const viewport = baseViewport;
        
        console.log('📐 Viewport Info:');
        console.log(`  Viewport Width: ${viewport.width}`);
        console.log(`  Viewport Height: ${viewport.height}`);
        console.log(`  Viewport Scale: ${viewport.scale}`);
        console.log(`  Page Width: ${viewport.width / viewport.scale}`);
        console.log(`  Page Height: ${viewport.height / viewport.scale}`);
        
        // Convert normalized coordinates to PDF coordinates (always at scale 1)
        const pdfCoords = viewport.convertToPdfPoint(normalizedX, normalizedY);
        
        // Get page dimensions in PDF coordinates
        const pageSize = page.getViewport({ scale: 1.0 });
        
        console.log('📐 PDF Coordinates:');
        console.log(`  PDF X (from left): ${pdfCoords[0].toFixed(2)}`);
        console.log(`  PDF Y (from top): ${pdfCoords[1].toFixed(2)}`);
        console.log(`  PDF Y (from bottom): ${(pageSize.height - pdfCoords[1]).toFixed(2)}`);
        console.log(`  Page Number: ${pageNumber}`);
        console.log(`  Page Size (PDF units): ${pageSize.width} x ${pageSize.height}`);
        
        // Calculate percentage positions
        const xPercent = (pdfCoords[0] / pageSize.width) * 100;
        const yPercent = (pdfCoords[1] / pageSize.height) * 100;
        
        console.log('📊 Percentage Positions:');
        console.log(`  X: ${xPercent.toFixed(2)}% from left`);
        console.log(`  Y: ${yPercent.toFixed(2)}% from top`);
        
        // Visual feedback (show at actual click position but with normalized coordinates)
        this.showCoordinateMarker(x, y, pdfCoords[0], pdfCoords[1], pageNumber, this.currentScale);
      } else {
        console.warn('⚠️ PDF Document not available');
      }
    } catch (error) {
      console.error('❌ Error getting PDF coordinates:', error);
    }
  }

  // Show visual coordinate marker
  showCoordinateMarker(x: number, y: number, pdfX: number, pdfY: number, pageNumber: number, currentZoom: number = 1) {
    // Create a temporary marker with coordinate info
    const marker = document.createElement('div');
    marker.style.position = 'absolute';
    marker.style.left = `${x - 5}px`;
    marker.style.top = `${y - 5}px`;
    marker.style.width = '10px';
    marker.style.height = '10px';
    marker.style.backgroundColor = 'red';
    marker.style.borderRadius = '50%';
    marker.style.border = '2px solid white';
    marker.style.zIndex = '1000';
    marker.style.pointerEvents = 'none';
    marker.style.boxShadow = '0 0 5px rgba(0,0,0,0.5)';
    
    // Create coordinate label with zoom info
    const label = document.createElement('div');
    label.style.position = 'absolute';
    label.style.left = `${x + 15}px`;
    label.style.top = `${y - 10}px`;
    label.style.backgroundColor = 'rgba(0,0,0,0.8)';
    label.style.color = 'white';
    label.style.padding = '4px 8px';
    label.style.borderRadius = '4px';
    label.style.fontSize = '12px';
    label.style.fontFamily = 'monospace';
    label.style.zIndex = '1001';
    label.style.pointerEvents = 'none';
    label.style.whiteSpace = 'nowrap';
    label.textContent = `X:${pdfX.toFixed(1)} Y:${pdfY.toFixed(1)} (Scale 1.0)`;
    
    // Add zoom indicator
    const zoomLabel = document.createElement('div');
    zoomLabel.style.position = 'absolute';
    zoomLabel.style.left = `${x + 15}px`;
    zoomLabel.style.top = `${y + 15}px`;
    zoomLabel.style.backgroundColor = 'rgba(0,100,200,0.8)';
    zoomLabel.style.color = 'white';
    zoomLabel.style.padding = '2px 6px';
    zoomLabel.style.borderRadius = '3px';
    zoomLabel.style.fontSize = '10px';
    zoomLabel.style.fontFamily = 'monospace';
    zoomLabel.style.zIndex = '1001';
    zoomLabel.style.pointerEvents = 'none';
    zoomLabel.style.whiteSpace = 'nowrap';
    zoomLabel.textContent = `Zoom: ${(currentZoom * 100).toFixed(0)}%`;
    
    // Add to the page
    const pageElement = document.querySelector(`.page[data-page-number="${pageNumber}"]`) as HTMLElement;
    if (pageElement) {
      pageElement.style.position = 'relative';
      pageElement.appendChild(marker);
      pageElement.appendChild(label);
      pageElement.appendChild(zoomLabel);
      
      // Remove markers after 3 seconds
      setTimeout(() => {
        if (marker.parentNode) {
          marker.parentNode.removeChild(marker);
        }
        if (label.parentNode) {
          label.parentNode.removeChild(label);
        }
        if (zoomLabel.parentNode) {
          zoomLabel.parentNode.removeChild(zoomLabel);
        }
      }, 3000);
    }
  }

  // Toggle coordinate detection mode
  toggleCoordinateMode() {
    this.isCoordinateMode = !this.isCoordinateMode;
    console.log(`🎯 Coordinate detection mode: ${this.isCoordinateMode ? 'ON' : 'OFF'}`);
    
    if (this.isCoordinateMode) {
      // Re-setup listeners when enabling
      setTimeout(() => {
        this.addCoordinateListeners();
      }, 500);
    } else {
      // Clean up listeners when disabling
      this.cleanupEventListeners();
    }
  }

  // Clean up event listeners
  private cleanupEventListeners() {
    this.clickHandlers.forEach((handler, element) => {
      element.removeEventListener('click', handler);
    });
    this.clickHandlers.clear();
    console.log('🧹 Event listeners cleaned up');
  }

}
